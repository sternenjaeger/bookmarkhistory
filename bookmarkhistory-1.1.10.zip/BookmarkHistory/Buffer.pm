########################################################################################################################
package Plugins::BookmarkHistory::Buffer;


#Values of a buffer entry:
# album_id:		Album ID of a bookmarked album
# genre:			Genre title
# album:			Album title
# artist: 		Artist title
# coverid: 		Cover ID
# url: 			URL of the bookmarked track
# ts: 			last time the track was played
# prebookmarked: 	If 1: Album is bookmarked to "Listen later". Will be set to 0 when track is played
# order:			Order of the entry in the Bookmarks menu. Is recalculated each time validate() is called (highest ts value gets listed first)

use Slim::Utils::Prefs;
#use Slim::Utils::DateTime;
use Slim::Utils::Log;
use Slim::Utils::Strings qw(cstring);

use Scalar::Util qw(looks_like_number);

my $log = logger('plugin.bookmarkHistory');

sub new {
	my ($class) = shift;

	my $self = {
		_buffer => preferences('plugin.bookmarkHistory')->get('buffer') || {}
	};
	

	validate($self);
	updateFromDatabase($self);
	
	return bless $self, $class;
}

sub verifyBuffer {
	my $class = shift;

	main::INFOLOG && $log->is_info && $log->info("verifyBuffer has been called");
	
	validate($class);
	updateFromDatabase($class);
			
}

sub get {
	my $class = shift;
	return $class->{_buffer};
}

sub add {
	my ($class, $item) = @_;

	my $id = $item->{album_id};
	my $buffer = $class->{_buffer};

	main::DEBUGLOG && $log->is_debug && $log->debug("New album_id:".$id);

	_itemAddLastTrackInfo($item);
	
	$item->{ts} = time;
	
	#Add info about last track in album to $info

	my $lasttrackurl=$item->{'lasttrackurl'};
	my $lasttracklength=$item->{'lasttracklength'};
	
	#check if we are near the end of the album
	if(
		$item->{url} eq $item->{'lasttrackurl'} &&
		$item->{position}>=( $item->{'lasttracklength'} - preferences('plugin.bookmarkHistory')->get('threshhold') )
	) {
		main::INFOLOG && $log->is_info && $log->info("Ignoring new bookmark because near end of album_id:".$id);
	} else {
		main::INFOLOG && $log->is_info && $log->info("new buffer entry album_id: " . $id);
		$buffer->{$id} = $item;

		#Validate buffer to check wether old bookmarks need to be dropped to keep buffer size to preference setting
		validate();
	}

}

sub storePosition {
	my ($class, $item) = @_;

	my $id = $item->{album_id};
	my $buffer = $class->{_buffer};

#	main::DEBUGLOG && $log->is_debug && $log->debug("id " . $id);
	#main::DEBUGLOG && $log->is_debug && $log->debug("buffer: \n" . Data::Dump::dump($buffer));
	
	if(!$id) {
		$log->warn("Missing id parameter");	
		return;
	}
	
	if( $item->{position}<preferences('plugin.bookmarkHistory')->get('threshhold') ) {
		main::DEBUGLOG && $log->is_debug && $log->debug("Ignoring because threshhold not reached");
		return;
	}
	
	if ( exists $buffer->{$id} ) {
		main::DEBUGLOG && $log->is_debug && $log->debug("Updating item: " . $id);
#		main::DEBUGLOG && $log->is_debug && $log->debug("Updating item: \n" . Data::Dump::dump($item));

		my $lasttrackurl=$buffer->{$id}->{lasttrackurl};
		my $lasttracklength=$buffer->{$id}->{lasttracklength};
		#my $threshhold=prefs->get('threshhold');

		main::DEBUGLOG && $log->is_debug && $log->debug("album check  album_id:".$item->{album_id}." position:".$item->{position}." lasttrackurl:".$lasttrackurl." lasttracklength:".$lasttracklength);

		if(
			$item->{url} eq $lasttrackurl and
			$item->{position}>=($lasttracklength-preferences('plugin.bookmarkHistory')->get('threshhold'))
		) {
			main::INFOLOG && $log->is_info && $log->info("Approaching end of album. Delete Bookmark for album_id:".$id);
			delete $buffer->{$id};

		} else {
			#update buffer
			$buffer->{$id}->{position} = $item->{position};
			#$buffer->{$id}->{tracknum} = $item->{tracknum};
			#$buffer->{$id}->{title} = $item->{title};
			$buffer->{$id}->{ts} = time;
			$buffer->{$id}->{url} = $item->{url};
			#update instead of setting hash to $item because otherwise lasttrackinfos would be lost
			#$buffer->{$id} = $item;

			$buffer->{$id}->{prebookmarked} = $item->{prebookmarked};# new value in 1.10
			
#			$log->info && $log->info("test buffer:".Data::Dump::dump($buffer->{$id}));

		}
		
	} else {
		main::DEBUGLOG && $log->is_debug && $log->debug("Switch to add mode");

		_itemAddLastTrackInfo($item);
		
		#Add info about last track in album to $info
	
		my $lasttrackurl=$item->{'lasttrackurl'};
		my $lasttracklength=$item->{'lasttracklength'};
		
		#check if we are near the end of the album
		if(
			$item->{url} eq $item->{'lasttrackurl'} &&
			$item->{position}>=( $item->{'lasttracklength'} - preferences('plugin.bookmarkHistory')->get('threshhold') )
		) {
			main::INFOLOG && $log->is_info && $log->info("Ignoring new bookmark because near end of album_is:".$id);
		} else {
			main::INFOLOG && $log->is_info && $log->info("Adding item: " . $id);
			add($class,$item);
		}

	}
}


sub getItem {
	my ($class, $id) = @_;

#main::INFOLOG && $log->is_info && $log->info("id :" . $id);
	
	return unless $id;
	
	#my ($item) = grep {
	#	$_->{_id} eq $id;
	#} %{$class->{_buffer}};
	
	#return $item;

	return $class->{_buffer}->{$id};
}

sub deleteItem {
	my ($class, $id) = @_;
	
	return unless $id;

	main::INFOLOG && $log->is_info && $log->info("deleteItem id".$id);
	
	delete $class->{_buffer}->{$id};
}

sub getItemAt {
	my ($class, $index) = @_;
	
	$class->{_buffer}->[$index || 0];
}

#sub getPlayers {
#	my ($class) = @_;
#	
#	my $players;
#	
#	foreach my $item ( %{$class->{_buffer}} ) {
#		foreach my $player ( %{$item->{clients}} ) {
#			$players->{$player}++;
#		}
#	}
#	
#	return $players;
#}

sub _itemAddLastTrackInfo {
	my ( $item) = @_;	
	
	if(!$item->{album_id}) {
		$log->warn("Missing id parameter");	
		return;
	}
	
	main::DEBUGLOG && $log->is_debug && $log->debug('check id:'.$item->{album_id});
	
	#Add info about last track in album to $info

	#get duration and url for all tracks in album
	my $request = Slim::Control::Request::executeRequest(undef,['titles', 0, 999, 'album_id:'.$item->{album_id}, 'sort:tracknum','tags:du']);

	if (!$request) {
		$log->warn("Failed to list album tracks for album_id:".$item->{album_id});
		return;
	}

	my $songinfo;
	
	eval {
		$songinfo = $request->getResults()->{titles_loop};
	};
	
	if ($@) {
		$log->warn("Failed to get list of titles for album_id ".$item->{album_id}.": $@\n" . Data::Dump::dump($request->getResults()));
		return;
	}

	#get last element of an array: http://www.perlhowto.com/array
	my $lasttrackinfo= @$songinfo[-1];


	my $lasttrackurl=$lasttrackinfo->{url}; #1.1.8 perl 5.014: Using a hash as a reference is deprecated 
	my $lasttracklength=$lasttrackinfo->{duration};
	#my $lasttrackurl=%$lasttrackinfo->{url};
	#my $lasttracklength=%$lasttrackinfo->{duration};
	
	$lasttracklength=int($lasttracklength);

	
	#main::DEBUGLOG && $log->is_debug && $log->debug("songinfo:\n" . Data::Dump::dump(@$songinfo[-1]));
	#main::DEBUGLOG && $log->is_debug && $log->debug("lasttrackinfo:\n" . Data::Dump::dump($lasttrackinfo));
	#main::DEBUGLOG && $log->is_debug && $log->debug("lasttrackurl:\n" . Data::Dump::dump($lasttrackurl));
	#main::DEBUGLOG && $log->is_debug && $log->debug("lasttracklength:\n" . Data::Dump::dump($lasttracklength));

	main::INFOLOG && $log->is_info && $log->info("Identified last track for album_id:".$item->{album_id}." url:".$lasttrackurl. " duration:".$lasttracklength);

	$item->{lasttrackurl}=$lasttrackurl;
	$item->{lasttracklength}=int($lasttracklength);

	return $item;

}

sub updateFromDatabase {
	my $class = shift;
	# initialize buffer from prefs if we haven't yet
	$class->{_buffer} ||= preferences('plugin.bookmarkHistory')->get('buffer');

	my $buffer 				= $class->{_buffer};
	my $newbuffer			={};

	my $exectime;
	main::INFOLOG && $log->is_info && $log->info("updateFromDatabase start") && ($exectime=time);
	
	my $oldbuffersize=scalar keys %$buffer;
	
	#check all buffer elements
	for my $id ( keys %$buffer ) {
		
		my $bufferitem=$buffer->{$id};

		#get current data of track from database
		my $meta=Plugins::BookmarkHistory::Plugin::getTrackItem('url',$bufferitem->{url});

		if (!$meta->{album_id}) {
			main::INFOLOG && $log->is_info && $log->warn("drop bookmark because not in filter list or not existing. url:".$bufferitem->{url});
		
		} elsif (looks_like_number($meta->{album_id}))  {
		
			my $newitem = {};
		
			#update from database
			$newitem->{album_id}	=$meta->{album_id};
			$newitem->{genre}		=$meta->{genre};
			$newitem->{album}		=$meta->{album};
			$newitem->{artist}		=$meta->{artist};
			$newitem->{coverid}		=$meta->{coverid};
			
			#IMPORTANT: All elemenents of a bookmark must be copied here. Otherwise they will be dropped when updateFromDatabase is called (server start)
			#keep from bookmark
			$newitem->{url}				=$bufferitem->{url};
			$newitem->{ts}				=$bufferitem->{ts};
			$newitem->{prebookmarked}	=$bufferitem->{prebookmarked}; # new in 1.10
			$newitem->{order}	        =$bufferitem->{order}; # new in 1.10

#work: fehlt check auf URL
			if (!looks_like_number($newitem->{ts})) 			{ $newitem->{ts}="" };
			if (!looks_like_number($newitem->{prebookmarked}))  { $newitem->{prebookmarked}=0 };
						
			if( $bufferitem->{position} < preferences('plugin.bookmarkHistory')->get('threshhold') ) {
				$newitem->{position}=0;
				$log->warn("clearing to small position. bufferitem:".$bufferitem->{url});
			} else {
				$newitem->{position} 	=$bufferitem->{position};
			}
			
			#add elements lastrackurl lasttracklength
			_itemAddLastTrackInfo($newitem);
						
			$newbuffer->{$meta->{album_id}}= $newitem;

		}


	}

	$class->{_buffer} = $newbuffer;
	preferences('plugin.bookmarkHistory')->set('buffer', $class->{_buffer});

	my $newbuffersize=scalar keys %$buffer;
	
	main::INFOLOG && $log->is_info && $log->info("updateFromDatabase runtime:" . (time-$exectime). " old buffer size:".$oldbuffersize." new buffer size:".$newbuffersize);
	
}

sub validate {
	my $class = shift;
	
	# initialize buffer from prefs if we haven't yet
	$class->{_buffer} ||= preferences('plugin.bookmarkHistory')->get('buffer');

	my $exectime;
	main::INFOLOG && $log->is_info && $log->info("validate start") && ($exectime=time);

	my $buffersize 			= preferences('plugin.bookmarkHistory')->get('bufferSize') || 0;
	my $buffer 				= $class->{_buffer};
			
	if (ref($buffer) ne "HASH") {
		return;
	}


	#in case some entry of the buffer is not a hash (could only occur because of bugs)
	for my $id ( keys %$buffer ) {
		if (ref($buffer->{$id}) ne "HASH") {
		
			$log->error("Dropping invalid buffer entry. This is an error and should not happen. album_id:" . $buffer->{$id});
			delete $buffer->{$id};
		
		}
	}
	
	my $id;
	my $item;
	
	#http://perlmaven.com/how-to-sort-a-hash-of-hashes-by-value
	#
	#my @positioned = sort { $data->{$a}{Position} <=> $data->{$b}{Position} } keys %$data;
	#foreach my $k (@positioned) {
	#say $k;
	#}

	my $currentbuffersize 	= scalar keys %$buffer; #http://stackoverflow.com/questions/1109095/how-can-i-find-the-number-of-keys-in-a-hash-in-perl
	main::INFOLOG && $log->is_info && $log->info("Validate currentbuffersize:" . $currentbuffersize . " buffersize:" . $buffersize);


	#sort by value of prebookmarked and ts: entries with prebookmarked get listed first, entried with the same value of prebookmarked get sorted by ts
	my @buffersortedbyts = sort {
		if (!$buffer->{$a}{prebookmarked}       && $buffer->{$b}{prebookmarked} == 1 ) {
			1
		} elsif ($buffer->{$a}{prebookmarked} == 1 && !$buffer->{$b}{prebookmarked} ) {
			-1
		} else {
			#sort by timestamp
			$buffer->{$a}{ts} <=> $buffer->{$b}{ts}
		}
	} keys %$buffer;

	#Recalculate order value and drop buffer items if max. size is exceeded
	my $order=0;
	foreach $id ( 0..($currentbuffersize-1) ) {
		if( $id <= ($currentbuffersize-$buffersize-1) ) {

			$log->warning("dropping bookmark album_id:" . $buffer->{$buffersortedbyts[$id]}->{id} . " album:" . $buffer->{$buffersortedbyts[$id]}->{album});
			delete $buffer->{$buffersortedbyts[$id]};

		} else {

			main::INFOLOG && $log->is_info && $log->info("reorder order=".$order." album:".$buffer->{$buffersortedbyts[$id]}->{album});
			$buffer->{$buffersortedbyts[$id]}->{order}=$order;
			$order=$order+1;
		}

	}

	preferences('plugin.bookmarkHistory')->set('buffer', $class->{_buffer});
	
	main::INFOLOG && $log->is_info && $log->info("validate runtime:" . (time-$exectime));

}


1;
