#Debugging:
#squeezeboxserver  --debug plugin.bookmarkHistory
#
#Author: Martin Johnen - based on "What was that tune" by Michael Herger
#  
#Use at you're own risk!
#
#Version 1.1.10
#Changed sort order in plugin menu: if the current track of a client is part of an bookmarked album it is always listed at the top, even if another client has a more recent timestamp
#Added a setting to configure a list of players who are ignored (i. e. they don't add bookmarks, existing bookmarks are not changed if an album is played on a player defined in this list)
#added context menu "Play from start" for "Album Info" and "Now Playing" (if bookmark exists)
#added context menu "Remove bookmark" for "Now Playing" and "Now Playing" (if bookmark exists)

#added "done" to rescanCallback to prevent that callback is called several times during rescan

#Notes:
#changed name Buffer->storeItem to storePosition 

#Version 1.1.9
#new context menu "play from start" with 
#removed deprecated warnings with perl 5.014
#corrected 0 as min. value for threshhold
#change of genre keywords preference didn't call verifyBuffer routine
#Version 1.1.6
#better handling of "Rewind button"
#Version 1.1.4
#removed playlist callback for "open"
#Version 1.1.1
# added "playlist open" to playlists callback
#Version 1.1:
#resolved issues:
#* Albums need to be tagged with tracknumbers starting from 1, otherwise the jump to the correct track will fail.
#* Rewind and next buttons wont work for bookmarked albums because these also trigger the newsong event which then jumps back to the bookmark.
#* If a genre is dropped from the "List of genres" setting it may happen that bookmarks of albums with this genre are kept in the bookmark list, even if they are fully played.
#* If you start an album from the "My Music" menu and you select the track that the bookmark is set to, the player will jump to the bookmarked position (if you select another track the track will play from the start and the plugin updates the bookmark
#* Because the plugin uses the album_id's to identify an album the bookmarks will be wiped when you perform a "Full rescan" of the database
 

package Plugins::BookmarkHistory::Plugin;

use strict;
use base qw(Slim::Plugin::OPMLBased);

use Digest::MD5 qw(md5_hex);

use Slim::Utils::DateTime;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(cstring);
use Slim::Utils::Timers;

use Plugins::BookmarkHistory::Buffer;

my $prefs = preferences('plugin.bookmarkHistory');

#Flag if a timer has been set for trackProgress()
my $activetracker = 0;

my $log = Slim::Utils::Log->addLogCategory( {
	category     => 'plugin.bookmarkHistory',
	defaultLevel => 'ERROR',
	description  => 'PLUGIN_BOOKMARKHISTORY',
} );

my ($buffer, $genreList);

#Called from handleFeed if a bookmark has been selected in the menu
#Request current client to stop playing, then loads the selected album into the playlist and jumps to the track stored in the bookmark
sub playBookmark {
	my ($client, $id ) = @_;
	my $myrequest;
	
	my $remoteMeta = $buffer->getItem($id);	
	
	$log->info("Creating playlist client:" . $client," id:".$id." metadata albumid:".$remoteMeta->{id}." album:".$remoteMeta->{album});

#	my $tracknum=$remoteMeta->{tracknum};
#	
#	#play_index in CLI command playlistcontrol cmd:load seems to start from 0
#	if ( $tracknum>0 ) {
#		$tracknum -= 1;
#	}

	$myrequest=Slim::Control::Request::executeRequest($client, ['stop']);
	$myrequest->getResults();

	$myrequest=Slim::Control::Request::executeRequest($client, ['playlistcontrol','cmd:load','album_id:'.$remoteMeta->{album_id}]);
#	$myrequest=Slim::Control::Request::executeRequest($client, ['playlistcontrol','cmd:load','album_id:'.$remoteMeta->{album_id},'play_index:'.$tracknum]);
	$myrequest->getResults();

	return;
}

sub initPlugin {
	my $class = shift;
	
	$buffer = Plugins::BookmarkHistory::Buffer->new();

	$prefs->init({
		buffer => {},
		bufferSize => 200,
		trackingPrecision => 5,
		threshhold  =>0,
		jumpback  =>0,
		sortDescending => 1,
		genreFilter => '',
		playerFilter => '',
		
	});
		
	$prefs->setChange( sub {
		$buffer->verifyBuffer() #1.1.7
	#		$buffer->validate()
	}, 'bufferSize');
	
	$prefs->setChange( sub {

		#1.1.7: use global variable so that trackinfo does not have to do the join/map command oder and over again
		$genreList ||= join('|', map {
			s/^\s*//;
			s/\s*$//;
			$_;
		} split(/,/, $prefs->get('genreFilter') || ''));

		$buffer->verifyBuffer(); #1.1.7

	}, 'genreFilter');
	

	if (main::WEBUI) {
		require Plugins::BookmarkHistory::Settings;
		Plugins::BookmarkHistory::Settings->new();
	}

	$genreList ||= join('|', map {
		s/^\s*//;
		s/\s*$//;
		$_;
	} split(/,/, $prefs->get('genreFilter') || ''));
		
	#Subscribe to playlist changes
	
	#Bookmarks menu works with loadalbum
	#Web interface seems to use addtracks
	#iPeng seems to use:
	#	playlist clear
	#	playlist stop
	#	playlist addtracks listRef ARRAY(0xXXXXXX) index%3A0
	#	playlist jump 0
	#	playlist open file ...

	#In all this cases use playlistCallback which looks through the playlist and if there is a bookmark for the album of the current playlists track then jump to this position

	#For up/down/move in the playlist the web interfaces and iPeng are using the "index" command.
	#Squeezeplay uses:
	#	playlist index N
	#	playlist stop
	#	playlist open 

	Slim::Control::Request::subscribe( \&playlistCallback, [['playlist'], ['loadtracks','loadalbum','addtracks' ]] );
#	Slim::Control::Request::subscribe( \&playlistCallback, [['playlist'], ['loadtracks','loadalbum','open','index']] );

	#Subscribe to newsong to jump to the correct position in the track once a bookmarked track is hit
	Slim::Control::Request::subscribe( \&newsongCallback, [['playlist'], ['newsong']] );

	# Subscribe to rescan to update album-id's of bookmarks after full scan
	Slim::Control::Request::subscribe( \&rescanCallback, [['rescan'],['done']]); #patch 1.1.10 added "done" 

	# Subscribe to Rewind Button to set track positioning to 0
	Slim::Control::Request::subscribe( \&buttonJumpRewCallback, [['button']]);

	
	Slim::Menu::TrackInfo->registerInfoProvider( bookmarkHistory => (
		after => 'top',
		func  => \&nowPlayingInfoMenu,
	) );

	#1.1.10 added context menu for album info
	Slim::Menu::AlbumInfo->registerInfoProvider( bookmarkHistory => (
		after => 'top',
		func => \&albumInfoMenu,
	) );
	
	###############################################################################################
	#define my own CLI commands

	# Slim::Control::Request::addDispatch([<TERMS>], [<DEFINITION>]);

	#Plugins::BookmarkHistory::CLI::cliDispatch($buffer);
	
	Slim::Control::Request::addDispatch(
		['bookmarkhistory', 'hasbookmark','_idtype','_id'], 
		[0, 1, 1, \&cliQueryHasBookmark]
	);

	###############################################################################################
	
	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'bookmarkHistory',
		is_app => 1,
	);
}
###############################################################################
#CLI Commands

sub cliQueryHasBookmark {
	my $request = shift;

	my $client = $request->client();
	#my $album_id = $request->getParam('albumid');
	my $idtype = $request->getParam('_idtype');
	my $id = $request->getParam('_id');

	my $album_id;
	
	main::INFOLOG && $log->is_info && $log->info("CLI call client:".$client." idtype:".$idtype." id:".$id);

	if($idtype eq 'albumid') {
		$album_id=$id;
	} elsif ($idtype eq 'url') {

		my $item=getTrackItem('url',$id);
		$album_id=$item->{album_id};
		
	} else {
		$request->setStatusBadParams();
		return;	
	}

	if (!defined $album_id) {
		$request->setStatusBadParams();
		return;
	}
	
	my $bufferitem = $buffer->getItem($album_id);

	if($bufferitem->{album_id}) {
		main::DEBUGLOG && $log->is_debug && $log->debug("CLI result hasbookmark=1");
		$request->addResult('_hasbookmark', '1');
	} else {
		main::DEBUGLOG && $log->is_debug && $log->debug("CLI result hasbookmark=0");
		$request->addResult('_hasbookmark', '0');
	}
	
	$request->setStatusDone();

}

###############################################################################
sub getDisplayName { 'PLUGIN_BOOKMARKHISTORY' }

sub handleFeed {
	my ($client, $cb, $params, $args) = @_;
	
	my $items = [];

	#$items = [];

	my $unsorted = $buffer->get();
	my @buffersortedbyts;

	my $url = Slim::Player::Playlist::url($client);
	my $currentitem=getTrackItem('url',$url);
	my $currentbufferitem = $buffer->getItem($currentitem->{album_id});
	my $current_albumid=$currentbufferitem->{album_id};
	

	main::INFOLOG && $log->is_info && $log->info("client:" .$client." current_albumid:".$current_albumid);
	
	#sort descending: http://stackoverflow.com/questions/10216419/sort-perl-hash-from-largest-to-smallest

	#change 1.1.10: Always list the current track of the clients playlist at the top if it has a bookmark
	@buffersortedbyts = sort {
		#if($a == $current_albumid) {
		#	-1
		#} elsif ($b == $current_albumid) {
		#	1
		#} elsif (!$unsorted->{$a}{prebooked}       && $unsorted->{$b}{prebooked} == 1 ) {
		#	-1
		#} elsif ($unsorted->{$a}{prebooked} == 1 && !$unsorted->{$b}{prebooked} ) {
		#	1
		#} else {
			#sort by timestamp
				$unsorted->{($prefs->get('sortDescending')) ? $b : $a}{order} 
			<=> 
				$unsorted->{($prefs->get('sortDescending')) ? $a : $b}{order} 
		#}
	} keys %$unsorted;

	#if (!$prefs->get('sortDescending')) {		
	#	@buffersortedbyts = sort { $unsorted->{$a}{ts} <=> $unsorted->{$b}{ts} } keys %$unsorted;
	#} else {
	#	@buffersortedbyts = sort { $unsorted->{$b}{ts} <=> $unsorted->{$a}{ts} } keys %$unsorted;
	#}
	
	#main::DEBUGLOG && $log->is_debug && $log->debug("buffersortedbyts: \n" . Data::Dump::dump(@buffersortedbyts));
	
	foreach my $id ( @buffersortedbyts ) {
		my $bufferitem=$unsorted->{$id};
		
		my $timestamp = Slim::Utils::DateTime::shortDateF($bufferitem->{ts});		
		#my $timestamp = Slim::Utils::DateTime::shortDateF($bufferitem->{ts}) . ' ' . Slim::Utils::DateTime::timeF($bufferitem->{ts});		
		my $url = $bufferitem->{url};

		main::INFOLOG && $log->is_info && $log->info("id :".$id." album:".$bufferitem->{album}."utl :".$url);

		my $item = {
			type  => 'link', #'playlist'
			name  => $timestamp . ' - ' .  $bufferitem->{album} . ' - ' . $bufferitem->{artist},
			line1 => $timestamp . ' - ' .  $bufferitem->{album},
			line2 => $bufferitem->{artist},
			style => 'itemplay',
			nextWindow => 'nowPlaying', #'parent' would move back to "My apps"
			#cache =>0,
			url   => sub {
				my ($client, $cb, $params, $args) = @_;
				my $id = $args->{id};
				
				#playBookmark ( $client, $id);

				main::INFOLOG && $log->is_info && $log->info("callback client:",$client." id:".$id);

				$cb->(
					playBookmark ( $client, $id)
				);
				
				#my ($client, $cb, $params, $args) = @_;
				#$cb->( Plugins::BookmarkHistory::Menu->menu( 
				#	$client, 
				#	$args->{id}, 
				#	{ menuMode => 'bookmarkHistory' } 
				#) );
			},
			passthrough => [{
				id => $id
			}]
		};
		
		#if ($bufferitem->{remote_title}) {
		#	$item->{name}  .= ' (' . $bufferitem->{remote_title} . ')';
		#	$item->{line2} .= ' - ' . $bufferitem->{remote_title};
		#}
		
		if ($bufferitem->{artwork_url}) {
			$item->{image} = $bufferitem->{artwork_url};
		}
		elsif ($bufferitem->{coverid}) {
			$item->{image} = 'music/' . $bufferitem->{coverid} . '/cover';
			$item->{icon}  = $bufferitem->{coverid};
		}
		
		$item->{name}  =~ s/^ - //;
		$item->{line1} =~ s/^ - //;
		$item->{line2} =~ s/^ - //;

		push @$items, $item;
	}
	
	$cb->({
		items => $items
	});
}

#1.1.10 context menu for album info
sub albumInfoMenu {
	my ($client, $url, $album, $remoteMeta, $tags, $filter) = @_;

	#$log->warn("c:".$client." u:".$url." al:".$album." f:".$filter);
	
	#$log->warn("filter:\n".Data::Dump::dump($filter));
	#{ artist_id => 32_618, genre_id => 663 }

	#$log->warn("remoteMeta:\n".Data::Dump::dump($remoteMeta));
	#{}

	#$log->warn("tags:\n".Data::Dump::dump($tags));
	#{ menuContext => "normal", menuMode => 1, playlistIndex => undef }
	
	#$log->warn("albumid:".$album->get_column("id"));
	#albumid:47063
	
	#c:Slim::Player::SqueezePlay=ARRAY(0xcf23168) 
	#u:db:album.title=Space%20Is%20the%20Place 
	#al:Slim::Schema::Album=HASH(0xcdfbfc8) 
	#f:HASH(0xa524bc8)

#	my $albumTitle = $album->title;
#	my @artists;
#	push @artists, $album->artistsForRoles('ARTIST'), $album->artistsForRoles('ALBUMARTIST');

#	return _objInfoHandler( $client, $artists[0]->name, $albumTitle );

	my $albumid=$album->get_column("id");

	main::INFOLOG && $log->is_info && $log->info("albumInfoMenu albumid:".$albumid." url:".$url." context:".$tags->{menuContext});
	
	if ( $albumid && $tags->{menuContext} && $tags->{menuContext} eq 'normal') {

		my $bufferitem = $buffer->getItem($albumid);

		if($bufferitem->{album_id}) {

			main::INFOLOG && $log->is_info && $log->info("albumInfoMenu add entry: from start");
			main::INFOLOG && $log->is_info && $log->info("albumInfoMenu add entry: stop and remove");
			return [{
				type        => 'link',
				name        => Slim::Utils::Strings::clientString($client,'PLUGIN_BOOKMARKHISTORY_CONTEXT_FROMSTART'),
				url         => \&cmdLoadFromStart,
				passthrough => [ $bufferitem->{album_id} ],
				favorites   => 0,
				nextWindow  => 'parent',
			},

			{
				type        => 'link',
				name        => Slim::Utils::Strings::clientString($client,'PLUGIN_BOOKMARKHISTORY_CONTEXT_REMOVE'),
				url         => \&cmdRemove,
				passthrough => [ $bufferitem->{album_id} ],
				favorites   => 0,
				nextWindow  => 'parent',
			}];

		#	return {
		#		type        => 'link',
		#		name        => Slim::Utils::Strings::clientString($client,'PLUGIN_BOOKMARKHISTORY_CONTEXT_FROMSTART'),
		#		url         => \&cmdLoadFromStart,
		#		passthrough => [ $bufferitem->{album_id} ],
		#		favorites   => 0,
		#		nextWindow  => 'parent',
		#	};
			
		} else {
			#context menu für album without bookmark

			main::INFOLOG && $log->is_info && $log->info("add context menu prebook url:".$url);
			
			return {
				type        => 'link',
				name        => Slim::Utils::Strings::clientString($client,'PLUGIN_BOOKMARKHISTORY_CONTEXT_PREBOOK'),
				url         => \&cmdPrebook,
				passthrough => [ 'album_id',$albumid ],
				favorites   => 0,
				nextWindow  => 'parent',
			};			
		}
	}
	
	return; #if we dont return at least undef we get an error message "AlbumInfo menu item "bookmarkHistory" failed: not an arrayref or hashref"
}

sub nowPlayingInfoMenu {
	my ( $client, $url, $track, $remoteMeta, $tags ) = @_;
	return unless $client && $tags;

	main::INFOLOG && $log->is_info && $log->info("client :".$client." menuContext:".$tags->{menuContext}." menuMode:".$tags->{menuMode}." pl index:".$tags->{playlistIndex}." ps index:".Slim::Player::Source::playingSongIndex($client));
	#main::INFOLOG && $log->is_info && $log->info("tags :" . Data::Dump::dump($tags));

	# add item to now playing context menu
	if (
			($tags->{menuContext} && $tags->{menuContext} eq 'playlist' && $tags->{playlistIndex} == Slim::Player::Source::playingSongIndex($client)) #from PlayHistory
		|| 	($tags->{menuMode} && $tags->{menuMode} eq 'trackinfo' && !defined $tags->{playlistIndex}) #from PlayHistory
		|| 	($tags->{menuMode} && $tags->{menuMode} eq 'track' ) # && !defined $tags->{playlistIndex}) #SqueezePlay track info context menu
		||  ($tags->{menuContext} && $tags->{menuContext} eq 'normal') #ipeng
	) {

		main::INFOLOG && $log->is_info && $log->info("Adding context menu");

		my $item=getTrackItem('url',$url);
		my $bufferitem = $buffer->getItem($item->{album_id});


		if($bufferitem->{album_id}) {

			main::INFOLOG && $log->is_info && $log->info("add context menu fromstart albumid:".$bufferitem->{album_id});

			return [{
				type        => 'link',
				name        => Slim::Utils::Strings::clientString($client,'PLUGIN_BOOKMARKHISTORY_CONTEXT_FROMSTART'),
				url         => \&cmdLoadFromStart,
				passthrough => [ $bufferitem->{album_id} ],
				favorites   => 0,
				nextWindow  => 'parent',
			},

			{
				type        => 'link',
				name        => Slim::Utils::Strings::clientString($client,'PLUGIN_BOOKMARKHISTORY_CONTEXT_REMOVE'),
				url         => \&cmdRemove,
				passthrough => [ $bufferitem->{album_id} ],
				favorites   => 0,
				nextWindow  => 'parent',
			}];
			
			#return {
			#	type        => 'link',
			#	name        => Slim::Utils::Strings::clientString($client,'PLUGIN_BOOKMARKHISTORY_CONTEXT_FROMSTART'),
			#	url         => \&cmdLoadFromStart,
			#	passthrough => [ $bufferitem->{album_id} ],
			#	favorites   => 0,
			#	nextWindow  => 'parent',#patch 1.1.10 changed to parent from 'nowPlaying',
			#};
			
		} else {
			#context menu für album without bookmark

			main::INFOLOG && $log->is_info && $log->info("add context menu prebook url:".$url);
			
			return {
				type        => 'link',
				name        => Slim::Utils::Strings::clientString($client,'PLUGIN_BOOKMARKHISTORY_CONTEXT_PREBOOK'),
				url         => \&cmdPrebook,
				passthrough => [ 'url',$url ],
				favorites   => 0,
				nextWindow  => 'parent',
			};
			
		};
	
#		return {
#			name => 'test',# $client->string(getDisplayName()),
#			type => 'link',
#			url  => \&handleFeed,
#			isContextMenu => 1,
#		};



	}
	
	return;
}

###############################################################################
#Context menu functions

sub cmdLoadFromStart {
	my ( $client, $callback, undef, $id ) = @_;

	my $myrequest;
	
	main::INFOLOG && $log->is_info && $log->info("cmdLoadFromStart client:".$client."id :".$id."callback :".$callback);

	$myrequest=Slim::Control::Request::executeRequest($client, ['stop']);
	$myrequest->getResults();

	$buffer	->deleteItem($id);

	my $item;
	$item = getTrackItem('album_id',$id);	
	$item->{prebookmarked}=1;
	$buffer->add($item);

	$myrequest=Slim::Control::Request::executeRequest($client, ['playlistcontrol','cmd:load','album_id:'.$id]);
	$myrequest->getResults();
	
#	my $menu = {
#		type        => 'text',
#		name        => Slim::Utils::Strings::string('PLUGIN_BOOKMARKHISTORY_STARTMSG'),
#		showBriefly => 1,
#		refresh     => 1,
#		favorites   => 0,
#	};
	
#	$callback->( [$menu] );

	return;
}

sub cmdRemove {
	my ( $client, $callback, undef, $id ) = @_;

	main::INFOLOG && $log->is_info && $log->info("cmdRemove client:".$client."id :".$id."callback :".$callback);

	Slim::Control::Request::executeRequest($client, ['playlistcontrol','cmd:delete','album_id:'.$id]);

	$buffer	->deleteItem($id);
	
}

sub cmdPrebook {
	my ( $client, $callback, undef, $idtype,$id ) = @_;

	my $myrequest;
	
	main::INFOLOG && $log->is_info && $log->info("cmdPrebook client:".$client."idtype :".$idtype." id:".$id."callback :".$callback);
	
	my $item;
	
	if ($idtype eq 'url' && $id ne '' ) {
	
		$item = getTrackItem('url',$id);

	} elsif ($idtype eq 'album_id' && $id!=0 ) {
		
		$item = getTrackItem('album_id',$id);	

	} else {
		
		$log->warn("no value for id");	
		return;
	}
	
	$item->{prebookmarked}=1;
	$buffer->add($item);
	

	return;
}

###############################################################################
#Callback functions
sub rescanCallback {

	$log->info("Verify bookmarks because of a rescan");

	$buffer->verifyBuffer();
}

sub playlistCallback {
	my $request = shift;
	my $client  = $request->client() || return;

	main::INFOLOG && $log->is_info && $log->info("playlistCallback client:".$client." request:". $request->getRequestString());

	my $cmd = $request->getRequestString();

	my $fromtrack = '-';
	my $numberoftracks = preferences('server')->get('maxPlaylistLength');
	

#	main::INFOLOG && $log->is_info && $log->info("getClientPlaylist client:$client fromtrack:$fromtrack numberoftracks:$numberoftracks");
	
#	$log->info($client.": playlists:\n" . Data::Dump::dump(Slim::Player::Playlist::playList($client)));
#	my $playList=Slim::Player::Playlist::playList($client);
#	$log->info($client.": playlist \n:" . Data::Dump::dump($playList));
#	
#	for my $i (0 .. $#{$playList}) {
#		my $trackinfo=$playList->[$i];
#		$log->info($client.": playlist $i:\n" . Data::Dump::dump($trackinfo));
#		$log->info($client.": playlist $i:\n" . $trackinfo->{title});
#		
#	$log->info("i:".$i." title:".$trackinfo->name());
#	#$log->info("i:".$i." title:".$trackinfo->albumid());
#	}

	#album_id genre url is tags:egu
	my $request = Slim::Control::Request::executeRequest($client, ['status', $fromtrack, $numberoftracks , 'tags:egu']);

#	my $timerequest = Slim::Control::Request::executeRequest($client, ['time','?']);

	my @items;

	if (!$request) {
		$log->warn("request failed. result is:" . Data::Dump::dump($request->getResults()));
		return;
	}
#		main::INFOLOG && $log->is_info && $log->info("request test. result is:" . Data::Dump::dump($request->getResults()));
	
	my $status;
	
	eval {
		$status = $request->getResults()->{playlist_loop};
	};
	
	if ($@) { #$@ is error code of eval
		$log->warn($client.": Failed to get song information: $@\n" . Data::Dump::dump($request->getResults()));
		return;
	}

	#first row: current song of playlist
	my $row = $status->[0];
	
	main::INFOLOG && $log->is_info && $log->info("current track of client:".$client." genre:".$row->{genre}." album_id:".$row->{album_id}." url:".$row->{url});
	
	if(!$row->{album_id}) {
		main::INFOLOG && $log->is_info && $log->info("no album_id. client:".$client);
		return;
	}
	
	#do we have a bookmark for the album of the current track?
	my $bufferitem = $buffer->getItem($row->{album_id});
	main::INFOLOG && $log->is_info && $log->info("bufferitem client:".$client." genre:".$bufferitem->{genre}." album_id:".$bufferitem->{album_id}." url:".$bufferitem->{url});

	if (!defined $bufferitem) { #1.1.8 perl 5.014: defined(%hash) is deprecated
#	if (defined %$bufferitem && !%$bufferitem) {
		main::INFOLOG && $log->is_info && $log->info("album of first track is not bookmarked. client:".$client);
		return;
	}

	if ($bufferitem->{url} eq "") {
		$log->warn("missing url in bookmark. client:".$client."album_id:".$bufferitem->{album_id});
		return;
	}


	if ($row->{url} eq "") {
		$log->warn("missing url in playlist. client:".$client."album_id:".$bufferitem->{album_id});
		return;
	}

	#did the client move in the playlist and did he move to a track different from the bookmarked track
	#if ( $cmd eq "playlist index" && $bufferitem->{url} ne $row->{url}) {
	#	main::INFOLOG && $log->is_info && $log->info("playlist index command");
	#	
	#	#update the bookmarked track
	#
	#	#we block small position values now in storePosition calls, so because the index command jumps to position 0 we have to update manually
	#	$bufferitem->{url}=$row->{url};
	#	$bufferitem->{position}=0;
	#
	#	return;
	#}

	#first row (=current playing track) is bookmarked track?
	
	if ($bufferitem->{url} eq $row->{url}) {
		main::INFOLOG && $log->is_info && $log->info("playlist current track is track of bookmark. client:".$client);
		return; 
	}

	#single row playlist
	if ( @$status == 1 ) {
		return;
	}
		
	main::INFOLOG && $log->is_info && $log->info("playlist rows url:".@$status);

	my $jumptracks=1;
	$row = $status->[$jumptracks];
	
	#loop through playlist while album is the same
	while($bufferitem->{album_id} eq $row->{album_id} & $jumptracks<@$status) {


		#track is the track of bookmark?
		if ($bufferitem->{url} eq $row->{url}) {
		
			#jumptracks contains the number of tracks we need to skip
			
			main::INFOLOG && $log->is_info && $log->info("executing index command index:+".$jumptracks." client:".$client);
			Slim::Control::Request::executeRequest($client, ['playlist','index','+'.$jumptracks]);
			return;

		}
		
		$jumptracks = $jumptracks +1;
		$row = $status->[$jumptracks];
		
	}
			
	main::INFOLOG && $log->is_info && $log->info("could not find bookmarked track in playlist. client:".$client);

}


sub newsongCallback {
	my $request = shift;
	my $client  = $request->client() || return;

	my $url = Slim::Player::Playlist::url($client);

	main::INFOLOG && $log->is_info && $log->info("newsongCallback client:".$client." request:". $request->getRequestString()." url:".$url);
	
	#get Track info for current track of client
	my $url = Slim::Player::Playlist::url($client);
	my $item=getTrackItem('url',$url);

	my $timerequest = Slim::Control::Request::executeRequest($client, ['time','?']);
    my $currrentposition = int($timerequest->getResult('_time'));

	if (!$timerequest) {
		$log->warn("time request failed. result is:" . Data::Dump::dump($timerequest->getResults()));
		return;
	}
	
	my $bufferitem = $buffer->getItem($item->{album_id});

	if($bufferitem->{album_id}) {
		#main::INFOLOG && $log->is_info && $log->info("found current playing album_id in buffer:\n".Data::Dump::dump($bufferitem));
		main::INFOLOG && $log->is_info && $log->info($client.": buffer hit album_id:".$item->{album_id});
		#main::INFOLOG && $log->is_info && $log->info($client.": current tracknum:".$item->{tracknum}. " stored tracknum:".$bufferitem->{tracknum});

		my $jumpback=$prefs->get('jumpback');
		
		if( $item->{album_id}==$bufferitem->{album_id} && $item->{url} eq $bufferitem->{url} ) {
			main::INFOLOG && $log->is_info && $log->info($client.": found bufferitem. positions are currrentposition:".$currrentposition." bufferitem:".$bufferitem->{position});
			

			#we never need to scoll back. this callback is subscribed to the newsong event, so current playing position in track will always be close to 0
			#BUT:
			#It looks like the "time" command also triggers the newsong event? Logging always shows two newsongCallback calls
			#I prevent recursive calls by also checking the current position in the track ($currrentposition)
			if( 
					( ($currrentposition)		>=0 																			) #check if we have a value
				&&	( ($currrentposition)		<$prefs->get('threshhold')												    	) #check if near the start 
				&&	( ($bufferitem->{position})	- $jumpback -($prefs->get('trackingPrecision') || 5) >$prefs->get('threshhold')	) #check if we have a value	 
				&& 	( ($bufferitem->{position}) - $jumpback -($prefs->get('trackingPrecision') || 5) >( ($item->{position}) )  	) #check if buffer pos. larger than play pos.
			) {
				if ( $jumpback>0 && $bufferitem->{position}>$jumpback ) {
					$log->info($client.": execute time command to position:".$bufferitem->{position}." jumpback:".$jumpback);
					Slim::Control::Request::executeRequest($client, ['time',$bufferitem->{position}-$jumpback]);					
				} else {
					$log->info($client.": execute time command to position:".$bufferitem->{position});
					Slim::Control::Request::executeRequest($client, ['time',$bufferitem->{position}]);
				}
			}
		}
	}	

	if (!$activetracker) {
		#Slim::Utils::Scheduler::add_task(\&trackProgress);
		main::INFOLOG && $log->is_info && $log->info($client.": create timer for trackProgress");
		Slim::Utils::Timers::setTimer( "", Time::HiRes::time() + ($prefs->get('trackingPrecision') || 1), \&trackProgress );
		$activetracker=1;
	} else {
		main::DEBUGLOG && $log->is_debug && $log->debug($client.": activetracker:".$activetracker);	
	}

}

sub buttonJumpRewCallback {
	my $request = shift;
	my $client  = $request->client() || return;

	main::INFOLOG && $log->is_info && $log->info("buttonJumpRewCallback client:".$client);

	#my $cmd = $request->getRequestString();
    #main::INFOLOG && $log->info("buttonJumpRewCallback cmd: $cmd\n");
    #main::INFOLOG && $log->info("buttonJumpRewCallback results:".$request->getResults());
	#main::INFOLOG && $log->info("request:".Data::Dump::dump($request));
	#main::INFOLOG && $log->info("getParam:".$request->getParam('_buttoncode'));
	
	if ($request->getParam('_buttoncode') eq 'jump_rew') {
		main::INFOLOG && $log->info("buttonJumpRewCallback caught jump_rew");

		#get current track of client
		my $url = Slim::Player::Playlist::url($client);
		my $item=getTrackItem('url',$url);
		
		if($buffer->get()->{$item->{album_id}}) {
		
			#we block small position values now in storePosition calls
			#$item->{position}='0';
			#$buffer->storePosition($item);
			$buffer->get()->{$item->{album_id}}->{url}=$url;   #1.1.4: The Rewind button also jumps to the previous track, so we update the url also here, not only position
			$buffer->get()->{$item->{album_id}}->{position}=0;
		}
	}
	

}

###############################################################################

#sub getPlayedItem {
#	my ($class, $id) = @_;
#	return $buffer->getItem($id);
#}

###############################################################################
#Returns an item for a track url. item includes the position of the client in track
#Parameters are:
#client
#url: URL of the track

sub getTrackItem {

	my $idtype = shift;
	my $id = shift;

	if ( $id eq '' ) {
		main::INFOLOG && $log->is_info && $log->info('empty parameter id');
		return;
	}
	
	#if ( !$client ) {
	#	main::INFOLOG && $log->is_info && $log->info("getTrackItem missing client:");
	#}
	
	#Requesting: url|album_id|genre|album|artist|coverid --> ueglac	
	my $request;
	
	if ($idtype eq 'url') { 
		$request = Slim::Control::Request::executeRequest(undef, ['songinfo', 0, 99, 'tags:ueglac','url:'. $id]);
	} elsif ($idtype eq 'album_id') {
		$request = Slim::Control::Request::executeRequest(undef, ['titles', 0, 99, 'tags:ueglac','album_id:'.$id]); 	
	} else {
		$log->warn("unknown value idtype:".$idtype);
		return;
	
	}
	
	
	#my $timerequest = Slim::Control::Request::executeRequest($client, ['time','?']);
    #my $positionvalue = int($timerequest->getResult('_time'));


	my $item = {};
	
	if (!$request) {
		$log->warn("request failed. result is:" . Data::Dump::dump($request->getResults()));
		return;
	}
	
	my $songinfo;

	if ($idtype eq 'url') { 	

		eval {
			$songinfo = $request->getResults()->{songinfo_loop};
		};
		
		if ($@) { #$@ is error code of eval
			$log->warn(": Failed to get song information: $@\n" . Data::Dump::dump($request->getResults()));
			return undef;
		}

		foreach (@$songinfo) {
			my ($k, $v) = each %$_;
			
			if ($k =~ /^(?:url|album_id|genre|album|artist|coverid)$/) {
				$item->{$k} = $v || '';
			}
		}
		
	} elsif ($idtype eq 'album_id') {

		$songinfo = $request->getResults()->{titles_loop}[0];
		
		$item->{url} = $songinfo->{url};
		$item->{album_id} = $songinfo->{album_id};
		$item->{genre} = $songinfo->{genre};
		$item->{album} = $songinfo->{album};
		$item->{artist} = $songinfo->{artist};
		$item->{coverid} = $songinfo->{coverid};
		
	};	
	
	if (!$item->{album_id}) {
		main::INFOLOG && $log->is_info && $log->info("no album id");
		return undef;
	}

	# filter genres
	if ( $item->{genre} !~ /\b(?:$genreList)\b/i ) {
		main::INFOLOG && $log->is_info && $log->info("getTrackItem no genre match for genre:".$item->{genre});
		return undef;
	}

	#$item->{ts}     = time; moved to buffer
	
	main::DEBUGLOG && $log->is_debug("getTrackItem returns album_id:".$item->{album_id}." url:".$item->{url});

	return $item;

}

sub trackProgress {

	my $client;
	my $gotplayer=0;
	
		
	foreach $client (Slim::Player::Client::clients()) {

		if(Slim::Player::Source::playmode($client) eq 'play') {

			my $clientName=Slim::Player::Client::name($client);
		
			#Patch Version 1.1.10: Check a list of players who should be ignored in tracking
			if( $prefs->get('playerFilter') =~ /.*[, ]*($clientName)[, ]*.*/) {
				main::DEBUGLOG && $log->is_debug && $log->debug("hit ignore list client:".$client);
			} else {
				$gotplayer = 1;
				_logTrack($client);
			}
		}
	}

	if ($gotplayer) {
		$activetracker=1;
		#main::DEBUGLOG && $log->is_debug && $log->debug("activetracker=".$activetracker);
		Slim::Utils::Timers::setTimer( "", Time::HiRes::time() + ($prefs->get('trackingPrecision') || 1), \&trackProgress );
	} else {
		main::INFOLOG && $log->is_info && $log->info("no client is playing. deactivate tracker");	
		$activetracker=0;
		
		#new in 1.10: reorder if no client is playing
		$buffer->validate();
	}

	return $activetracker;
}

sub _logTrack {
	my $client = shift;

	my $url = Slim::Player::Playlist::url($client);

	my $meta=getTrackItem('url',$url);

	my $timerequest = Slim::Control::Request::executeRequest($client, ['time','?']);
    my $positionvalue = int($timerequest->getResult('_time'));

	if (!$timerequest) {
		$log->warn("time request failed. result is:" . Data::Dump::dump($timerequest->getResults()));
		return;
	}
	
	if (!$meta->{album_id}) {
		main::DEBUGLOG && $log->is_debug && $log->debug("no album id");
		return;
	}
	
	main::DEBUGLOG && $log->is_debug && $log->debug("id=". $meta->{album_id} . " position" . $meta->{position});

	$meta->{position} = $positionvalue;
	$meta->{prebookmarked}=0; # new value in 1.10
	$buffer->storePosition($meta);
}


1;
