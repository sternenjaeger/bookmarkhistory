package Plugins::BookmarkHistory::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;

my $prefs = preferences('plugin.bookmarkHistory');

sub name {
	return 'PLUGIN_BOOKMARKHISTORY';
}

sub prefs {
	return ($prefs, 'genreFilter','playerFilter', 'bufferSize', 'trackingPrecision', 'threshhold', 'jumpback', 'sortDescending');
}

sub page {
	return 'plugins/BookmarkHistory/settings.html';
}

1;