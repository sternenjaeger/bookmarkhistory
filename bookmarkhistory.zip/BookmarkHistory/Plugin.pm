#Debugging:
#squeezeboxserver  --debug plugin.bookmarkHistory
#
#Author: Martin Johnen - based on "What was that tune" by Michael Herger
#  
#Use at you're own risk!
# 
#known issues:
#
#* Albums need to be tagged with tracknumbers starting from 1, otherwise the jump to the correct track will fail.
#* Rewind and next buttons wont work for bookmarked albums because these also trigger the newsong event which then jumps back to the bookmark.
#* If a genre is dropped from the "List of genres" setting it may happen that bookmarks of albums with this genre are kept in the bookmark list, even if they are fully played.
#* If you start an album from the "My Music" menu and you select the track that the bookmark is set to, the player will jump to the bookmarked position (if you select another track the track will play from the start and the plugin updates the bookmark
#* Because the plugin uses the album_id's to identify an album the bookmarks will be wiped when you perform a "Full rescan" of the database



package Plugins::BookmarkHistory::Plugin;

use strict;
use base qw(Slim::Plugin::OPMLBased);

use Digest::MD5 qw(md5_hex);

use Slim::Utils::DateTime;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(cstring);
use Slim::Utils::Timers;

my $prefs = preferences('plugin.bookmarkHistory');

#Flag if a timer has been set for trackProgress()
my $activetracker = 0;

my $log = Slim::Utils::Log->addLogCategory( {
	category     => 'plugin.bookmarkHistory',
	defaultLevel => 'ERROR',
	description  => 'PLUGIN_BOOKMARKHISTORY',
} );

my ($buffer, $genreList);

#Called from handleFeed if a bookmark has been selected in the menu
#Request current client to stop playing, then loads the selected album into the playlist and jumps to the track stored in the bookmark
sub playBookmark {
	my ($client, $id ) = @_;
	my $myrequest;
	
	my $remoteMeta = Plugins::BookmarkHistory::Plugin->getPlayedItem($id);	
	
	$log->info("Creating playlist for id " . $id . " for client " . $client);

	my $tracknum=$remoteMeta->{tracknum};
	
	#play_index in CLI command playlistcontrol cmd:load seems to start from 0
	if ( $tracknum>0 ) {
		$tracknum -= 1;
	}

	$myrequest=Slim::Control::Request::executeRequest($client, ['stop']);
	$myrequest->getResults();

	$myrequest=Slim::Control::Request::executeRequest($client, ['playlistcontrol','cmd:load','album_id:'.$remoteMeta->{album_id},'play_index:'.$tracknum]);
	$myrequest->getResults();

	return;
}

sub initPlugin {
	my $class = shift;
	
	$buffer = Plugins::BookmarkHistory::Buffer->new();

	$prefs->init({
		buffer => {},
		bufferSize => 200,
		trackingPrecision => 5,
		threshhold  =>1,
		jumpback  =>0,
		sortDescending => 1,
		genreFilter => '',
	});
	
	$prefs->setChange( sub {
		$buffer->validate()
	}, 'bufferSize');
	
	$prefs->setChange( sub {
		$genreList = '';
	}, 'genreFilter');
	
	$prefs->migrate(1, sub {
		my $buffer = $prefs->get('buffer');
		
		$buffer = [ map {
			$_->{clients} = [ $_->{clients} ] if $_->{clients} && ref $_->{clients} eq 'SCALAR';
			$_->{clients} = [] unless $_->{clients} && ref $_->{clients} eq 'ARRAY';
			$_;
		} %$buffer ];
		
		$prefs->set('buffer', $buffer);
	});

	if (main::WEBUI) {
		require Plugins::BookmarkHistory::Settings;
		Plugins::BookmarkHistory::Settings->new();
	}

	#Subscribe to newsong
	Slim::Control::Request::subscribe( \&newsongCallback, [['playlist'], ['newsong']] );

	# Subscribe to wipecache to clear bookmarks after full scan
	Slim::Control::Request::subscribe( \&wipecacheCallback, [['wipecache']]);
	
	Slim::Menu::TrackInfo->registerInfoProvider( bookmarkHistory => (
		after => 'top',
		func  => \&nowPlayingInfoMenu,
	) );

	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'bookmarkHistory',
		is_app => 1,
	);
}

sub getDisplayName { 'PLUGIN_BOOKMARKHISTORY' }

sub handleFeed {
	my ($client, $cb, $params, $args) = @_;
	
	my $items = [];

	#$items = [];

	my $unsorted = $buffer->get();
	my @buffersortedbyts;
	
	#sort descending: http://stackoverflow.com/questions/10216419/sort-perl-hash-from-largest-to-smallest
	if (!$prefs->get('sortDescending')) {		
		@buffersortedbyts = sort { $unsorted->{$a}{ts} <=> $unsorted->{$b}{ts} } keys %$unsorted;
	} else {
		@buffersortedbyts = sort { $unsorted->{$b}{ts} <=> $unsorted->{$a}{ts} } keys %$unsorted;
	}
	
	#main::DEBUGLOG && $log->is_debug && $log->debug("buffersortedbyts: \n" . Data::Dump::dump(@buffersortedbyts));
	
	foreach my $i ( @buffersortedbyts ) {
		my $bufferitem=$unsorted->{$i};
		my $timestamp = Slim::Utils::DateTime::shortDateF($bufferitem->{ts}) . ' ' . Slim::Utils::DateTime::timeF($bufferitem->{ts});		
		my $url = $bufferitem->{url};
		
		my $item = {
			type  => 'link',
			name  => $timestamp . ' - ' .  $bufferitem->{album} . ' - ' . $bufferitem->{artist},
			line1 => $timestamp . ' - ' .  $bufferitem->{album},
			line2 => $bufferitem->{artist},
			style => 'itemplay',
			nextWindow => 'nowPlaying',
			url   => sub {
				my ($client, $cb, $params, $args) = @_;
				my $id = $args->{id};
				
				#playBookmark ( $client, $id);

				$cb->(
					playBookmark ( $client, $id)
				);
				
				#my ($client, $cb, $params, $args) = @_;
				#$cb->( Plugins::BookmarkHistory::Menu->menu( 
				#	$client, 
				#	$args->{id}, 
				#	{ menuMode => 'bookmarkHistory' } 
				#) );
			},
			passthrough => [{
				id => $bufferitem->{_id}
			}]
		};
		
		#if ($bufferitem->{remote_title}) {
		#	$item->{name}  .= ' (' . $bufferitem->{remote_title} . ')';
		#	$item->{line2} .= ' - ' . $bufferitem->{remote_title};
		#}
		
		if ($bufferitem->{artwork_url}) {
			$item->{image} = $bufferitem->{artwork_url};
		}
		elsif ($bufferitem->{coverid}) {
			$item->{image} = 'music/' . $bufferitem->{coverid} . '/cover';
			$item->{icon}  = $bufferitem->{coverid};
		}
		
		$item->{name}  =~ s/^ - //;
		$item->{line1} =~ s/^ - //;
		$item->{line2} =~ s/^ - //;

		push @$items, $item;
	}
	
	$cb->({
		items => $items
	});
}

sub nowPlayingInfoMenu {
	my ( $client, $url, $track, $remoteMeta, $tags ) = @_;

	return unless $client && $tags;

	# add item to now playing context menu
	if ( ($tags->{menuContext} && $tags->{menuContext} eq 'playlist' && $tags->{playlistIndex} == Slim::Player::Source::playingSongIndex($client))
		|| ($tags->{menuMode} && $tags->{menuMode} eq 'trackinfo' && !defined $tags->{playlistIndex})
	) {
		return {
			name => $client->string(getDisplayName()),
			type => 'link',
			url  => \&handleFeed,
			isContextMenu => 1,
		};
	}
	
	return;
}

sub getPlayedItem {
	my ($class, $id) = @_;
	return $buffer->getItem($id);
}

sub wipecacheCallback {

	$log->warn("Clearing bookmarks because of a full rescan");

	$buffer->emptyBuffer();
}

sub newsongCallback {


	my $request = shift;
	my $client  = $request->client() || return;

	my $url = Slim::Player::Playlist::url($client);

	my $request = Slim::Control::Request::executeRequest($client, ['songinfo', 0, 99, 'url:' . $url]);

	my $timerequest = Slim::Control::Request::executeRequest($client, ['time','?']);
    my $positionvalue = int($timerequest->getResult('_time'));

	main::DEBUGLOG && $log->is_debug && $log->debug("newsongCallback client:".$client);
	
	if ($request) {
		#main::DEBUGLOG && $log->is_debug && $log->debug(Data::Dump::dump($request->getResults()));
		
		my $songinfo;
		
		eval {
			$songinfo = $request->getResults()->{songinfo_loop};
		};
		
		if ($@) {
			$log->warn($client.": Failed to get song information: $@\n" . Data::Dump::dump($request->getResults()));
			return;
		}

		my $item = {};
		foreach (@$songinfo) {
			my ($k, $v) = each %$_;
			
			if ($k =~ /^(?:id|album_id|album|tracknum)$/) {
				$item->{$k} = $v || '';
			}
		}

		if (!$item->{album_id}) {
			main::INFOLOG && $log->is_info && $log->info("no album id");
			return;
		}
		
		$item->{url}    = $url;
		$item->{ts}     = time;
#		$item->{_id}    = $item->{album_id};
		$item->{position} = $positionvalue;
#		$item->{client} = $client->id;
#		$item->{clients} = [ $item->{client}, map { $_->id } Slim::Player::Sync::slaves($client) ];

		my $bufferitem = $buffer->getItem($item->{album_id});

		if($bufferitem) {
			#main::INFOLOG && $log->is_info && $log->info("found current playing album_id in buffer:\n".Data::Dump::dump($bufferitem));
			main::INFOLOG && $log->is_info && $log->info($client.": buffer hit album_id:".$item->{album_id});
			main::INFOLOG && $log->is_info && $log->info($client.": current tracknum:".$item->{tracknum}. " stored tracknum:".$bufferitem->{tracknum});

			my $jumpback=$prefs->get('jumpback');
			
			if( $item->{album_id}==$bufferitem->{album_id} && $item->{tracknum}==$bufferitem->{tracknum} ) {
				main::INFOLOG && $log->is_info && $log->info($client.": found bufferitem. positions are item:".$item->{position}." bufferitem:".$bufferitem->{position});

				#we never need to scoll back. this callback is subscribed to the newsong event, so current playing position in track will always be close to 0
				if( 
						( ($item->{position})		>=0 																) #check if we have a value	 0
					&&	( ($item->{position})		<5									    							) #check if near the start (just to be safe	 )
					&&	( ($bufferitem->{position})	>0  																) #check if we have a value	 
					&& 	( ($bufferitem->{position}) >( ($item->{position}) - ($prefs->get('trackingPrecision') || 5) ) 	) #check if buffer pos. larger than play pos.
				) {
					if ( $jumpback>0 && $bufferitem->{position}>$jumpback ) {
						$log->info($client.": execute time command to position:".$bufferitem->{position}." jumpback:".$jumpback);
						Slim::Control::Request::executeRequest($client, ['time',$bufferitem->{position}-$jumpback]);					
					} else {
						$log->info($client.": execute time command to position:".$bufferitem->{position});
						Slim::Control::Request::executeRequest($client, ['time',$bufferitem->{position}]);
					}
				}
			}
		}	

		if (!$activetracker) {
			#Slim::Utils::Scheduler::add_task(\&trackProgress);
			main::INFOLOG && $log->is_info && $log->info($client.": create timer for trackProgress");
			Slim::Utils::Timers::setTimer( "", Time::HiRes::time() + ($prefs->get('trackingPrecision') || 1), \&trackProgress );
			$activetracker=1;
		} else {
			main::DEBUGLOG && $log->is_debug && $log->debug($client.": activetracker:".$activetracker);	
		}

	}
}

sub trackProgress {

	my $client;
	my $gotplayer=0;
		
	foreach $client (Slim::Player::Client::clients()) {

		if(Slim::Player::Source::playmode($client) eq 'play') {
			$gotplayer = 1;
			
			_logTrack($client);
		}
	}

	if ($gotplayer) {
		$activetracker=1;
		#main::DEBUGLOG && $log->is_debug && $log->debug("activetracker=".$activetracker);
		Slim::Utils::Timers::setTimer( "", Time::HiRes::time() + ($prefs->get('trackingPrecision') || 1), \&trackProgress );
	} else {
		main::INFOLOG && $log->is_info && $log->info("no client is playing. deactivate tracker");	
		$activetracker=0;
	}

	return $activetracker;
}

sub _logTrack {
	my $client = shift;
	
	my $url = Slim::Player::Playlist::url($client);

	my $request = Slim::Control::Request::executeRequest($client, ['songinfo', 0, 99, 'url:' . $url]);

	my $timerequest = Slim::Control::Request::executeRequest($client, ['time','?']);
    my $positionvalue = int($timerequest->getResult('_time'));

	#ignore if smaller than min. threshhold
	if ( $positionvalue < ($prefs->get('threshhold')) ) {
		return;
	}

	if ($request) {
		#main::DEBUGLOG && $log->is_debug && $log->debug(Data::Dump::dump($request->getResults()));
		
		my $songinfo;
		
		eval {
			$songinfo = $request->getResults()->{songinfo_loop};
		};
		
		if ($@) {
			$log->warn("Failed to get song information: $@\n" . Data::Dump::dump($request->getResults()));
			return;
		}

		my $meta = {};
		foreach (@$songinfo) {
			my ($k, $v) = each %$_;
			
			if ($k =~ /^(?:id|album_id|album|tracknum|title|remote_title|genre|artist|artwork_url|coverid)$/) {
				$meta->{$k} = $v || '';
			}
		}
		
		$genreList ||= join('|', map {
			s/^\s*//;
			s/\s*$//;
			$_;
		} split(/,/, $prefs->get('genreFilter') || ''));

		#main::DEBUGLOG && $log->is_debug && $log->debug("album:" . $meta->{album} );
		#main::DEBUGLOG && $log->is_debug && $log->debug("genreList:" . $genreList );

		if (!$meta->{album_id}) {
			main::DEBUGLOG && $log->is_debug && $log->debug("no album id");
			return;
		}
		
		# filter genres
		if ( $meta->{genre} !~ /\b(?:$genreList)\b/i ) {
#		if ( $meta->{title} =~ /\b(?:$genreList)\b/i || $meta->{artist} =~ /\b(?:$genreList)\b/i ) {
			#main::DEBUGLOG && $log->is_debug && $log->debug("Ignoring track, genre not in genrelist: '$genreList' - " . $meta->{album} . ' - ' . $meta->{genre});
			return;
		}
		
		$meta->{url}    = $url;
		$meta->{ts}     = time;
		$meta->{_id}    = $meta->{album_id};
		$meta->{position} = $positionvalue;
#		$meta->{client} = $client->id;
#		$meta->{clients} = [ $meta->{client}, map { $_->id } Slim::Player::Sync::slaves($client) ];

		main::DEBUGLOG && $log->is_debug && $log->debug("id=". $meta->{album_id} . " position" . $positionvalue);

		$buffer->storePosition($meta);
	}
}

1;

########################################################################################################################
# wrapper package around the buffer pref - make sure sort order, structure etc. are ok
package Plugins::BookmarkHistory::Buffer;

sub new {
	my $class = shift;
	
	my $self = {
#work
		_buffer => $prefs->get('buffer') || {}
#		_buffer => $prefs->get('buffer') || []
	};
	
	validate($self);
	
	return bless $self, $class;
}

sub emptyBuffer {
	my $class = shift;

	main::DEBUGLOG && $log->is_debug && $log->debug("Clearing Bookmark buffer");
	$class->{_buffer} = {};
	$prefs->set('buffer', $class->{_buffer});
		
}

sub get {
	my $class = shift;
	return $class->{_buffer};
}

sub storePosition {
	my ($class, $item) = @_;

	my $id = $item->{_id};
	my $buffer = $class->{_buffer};

#	main::DEBUGLOG && $log->is_debug && $log->debug("id " . $id);
	#main::DEBUGLOG && $log->is_debug && $log->debug("buffer: \n" . Data::Dump::dump($buffer));
	
	if(!$id) {
		$log->warn("Missing id parameter");	
		return;
	}
	
	if ( exists $buffer->{$id} ) {
		main::DEBUGLOG && $log->is_debug && $log->debug("Updating item: " . $id);
#		main::DEBUGLOG && $log->is_debug && $log->debug("Updating item: \n" . Data::Dump::dump($item));

		my $lasttracknum=$buffer->{$id}->{lasttracknum};
		my $lasttracklength=$buffer->{$id}->{lasttracklength};
		#my $threshhold=prefs->get('threshhold');

		#main::DEBUGLOG && $log->is_debug && $log->debug("album check  tracknum:".$item->{tracknum}." lasttracknum:".$lasttracknum." position:".$item->{position}." lasttracklength:".$lasttracklength);

		if(
			$item->{tracknum} == $lasttracknum and
			$item->{position}>=($lasttracklength-$prefs->get('threshhold'))
		) {
			main::INFOLOG && $log->is_info && $log->info("Approaching end of album. Delete Bookmark for album_id:".$id);
			delete $buffer->{$id};

		} else {
			#update buffer
			$buffer->{$id}->{position} = $item->{position};
			$buffer->{$id}->{tracknum} = $item->{tracknum};
			$buffer->{$id}->{title} = $item->{title};
			$buffer->{$id}->{ts} = $item->{ts};
			$buffer->{$id}->{url} = $item->{url};
			#update instead of setting hash to $item because otherwise lasttrackinfos would be lost
			#$buffer->{$id} = $item;
		}
		
	} else {
		main::DEBUGLOG && $log->is_debug && $log->debug("Switch to add mode");
		
		#Add info about last track in album to $info
	
		my $request = Slim::Control::Request::executeRequest(undef,['titles', 0, 999, 'album_id:'.$id, 'sort:tracknum']);

		if (!$request) {
			$log->warn("Failed to list album tracks for album_id:".$id);
			return;
		}
	

		my $songinfo;
		
		eval {
			$songinfo = $request->getResults()->{titles_loop};
		};
		
		if ($@) {
			$log->warn("Failed to get list of titles for album_id ".$id.": $@\n" . Data::Dump::dump($request->getResults()));
			return;
		}

		#get last element of an array: http://www.perlhowto.com/array
		my $lasttrackinfo= @$songinfo[-1];
		my $lasttracknum=%$lasttrackinfo->{'tracknum'};
		my $lasttracklength=%$lasttrackinfo->{'duration'};
		
		$lasttracklength=int($lasttracklength);
		
		#main::DEBUGLOG && $log->is_debug && $log->debug("songinfo:\n" . Data::Dump::dump(@$songinfo[-1]));
		#main::DEBUGLOG && $log->is_debug && $log->debug("lasttrackinfo:\n" . Data::Dump::dump($lasttrackinfo));
		#main::DEBUGLOG && $log->is_debug && $log->debug("lasttracknum:\n" . Data::Dump::dump($lasttracknum));
		#main::DEBUGLOG && $log->is_debug && $log->debug("lasttracklength:\n" . Data::Dump::dump($lasttracklength));

		main::INFOLOG && $log->is_info && $log->info("Identified last track for album_id:".$id." tracknum:".$lasttracknum. " duration:".$lasttracklength);

		#check if we are near the end of the album
		if(
			$item->{tracknum} == $lasttracknum and
			$item->{position}>=($lasttracklength-$prefs->get('threshhold'))
		) {
			main::DEBUGLOG && $log->is_debug && $log->debug("Ignoring new bookmark because near end of album_is:".$id);
		} else {
			main::INFOLOG && $log->is_info && $log->info("Adding item: " . $id);
			$buffer->{$id} = $item;
			$buffer->{$id}->{lasttracknum}=$lasttracknum;
			$buffer->{$id}->{lasttracklength}=int($lasttracklength);

			#Validate buffer to check wether old bookmarks need to be dropped to keep buffer size to preference setting
			$class->validate();
		}

	}
}

sub getItem {
	my ($class, $id) = @_;
	
	return unless $id;
	
	#my ($item) = grep {
	#	$_->{_id} eq $id;
	#} %{$class->{_buffer}};
	
	#return $item;

	return $class->{_buffer}->{$id};
}

sub deleteItem {
	my ($class, $id) = @_;
	
	return unless $id;
	
	delete $class->{_buffer}->{$id};
}

sub getItemAt {
	my ($class, $index) = @_;
	
	$class->{_buffer}->[$index || 0];
}

#sub getPlayers {
#	my ($class) = @_;
#	
#	my $players;
#	
#	foreach my $item ( %{$class->{_buffer}} ) {
#		foreach my $player ( %{$item->{clients}} ) {
#			$players->{$player}++;
#		}
#	}
#	
#	return $players;
#}

sub validate {
	my $class = shift;
	
	# initialize buffer from prefs if we haven't yet
	$class->{_buffer} ||= $prefs->get('buffer');

	my $buffersize 			= $prefs->get('bufferSize') || 200;
	my $buffer 				= $class->{_buffer};
	my $currentbuffersize 	= scalar keys %$buffer; #http://stackoverflow.com/questions/1109095/how-can-i-find-the-number-of-keys-in-a-hash-in-perl
	
	main::DEBUGLOG && $log->is_debug && $log->debug("Validate currentbuffersize " . $currentbuffersize . " buffersize " . $buffersize);
	
	if ( $currentbuffersize > $buffersize ) {

		main::INFOLOG && $log->is_info && $log->info("Exeeded buffer size. Dropping items" );

		my $id;
		my $item;
		
		#recalculate number of buffer entries
		$currentbuffersize 	= scalar keys %$buffer;

		#http://perlmaven.com/how-to-sort-a-hash-of-hashes-by-value
		#
		#my @positioned = sort { $data->{$a}{Position} <=> $data->{$b}{Position} } keys %$data;
		#foreach my $k (@positioned) {
		#say $k;
		#}

		my @buffersortedbyts = sort { $buffer->{$a}{ts} <=> $buffer->{$b}{ts} } keys %$buffer;
		
		foreach $id ( 0..($currentbuffersize-$buffersize-1) ) {
			main::INFOLOG && $log->is_info && $log->info("dropping bookmark album_id:" . $buffer->{$buffersortedbyts[$id]}->{id} . " album:" . $buffer->{$buffersortedbyts[$id]}->{album});
			delete $buffer->{$buffersortedbyts[$id]};
		}
		

	}

	$prefs->set('buffer', $class->{_buffer});
}

1;
