#Debugging:
#squeezeboxserver  --debug plugin.bookmarkHistory
#
#Author: Martin Johnen - based on "What was that tune" by Michael Herger
#  
#Use at you're own risk!
#
#Version 1.1.6
#better handling of "Rewind button"
#Version 1.1.4
#removed playlist callback for "open"
#Version 1.1.1
# added "playlist open" to playlists callback
#Version 1.1:
#resolved issues:
#* Albums need to be tagged with tracknumbers starting from 1, otherwise the jump to the correct track will fail.
#* Rewind and next buttons wont work for bookmarked albums because these also trigger the newsong event which then jumps back to the bookmark.
#* If a genre is dropped from the "List of genres" setting it may happen that bookmarks of albums with this genre are kept in the bookmark list, even if they are fully played.
#* If you start an album from the "My Music" menu and you select the track that the bookmark is set to, the player will jump to the bookmarked position (if you select another track the track will play from the start and the plugin updates the bookmark
#* Because the plugin uses the album_id's to identify an album the bookmarks will be wiped when you perform a "Full rescan" of the database
 

package Plugins::BookmarkHistory::Plugin;

use strict;
use base qw(Slim::Plugin::OPMLBased);

use Digest::MD5 qw(md5_hex);

use Slim::Utils::DateTime;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(cstring);
use Slim::Utils::Timers;

my $prefs = preferences('plugin.bookmarkHistory');

#Flag if a timer has been set for trackProgress()
my $activetracker = 0;

my $log = Slim::Utils::Log->addLogCategory( {
	category     => 'plugin.bookmarkHistory',
	defaultLevel => 'ERROR',
	description  => 'PLUGIN_BOOKMARKHISTORY',
} );

my ($buffer, $genreList);

#Called from handleFeed if a bookmark has been selected in the menu
#Request current client to stop playing, then loads the selected album into the playlist and jumps to the track stored in the bookmark
sub playBookmark {
	my ($client, $id ) = @_;
	my $myrequest;
	
	my $remoteMeta = Plugins::BookmarkHistory::Plugin->getPlayedItem($id);	
	
	$log->info("Creating playlist for id " . $id . " for client " . $client);

#	my $tracknum=$remoteMeta->{tracknum};
#	
#	#play_index in CLI command playlistcontrol cmd:load seems to start from 0
#	if ( $tracknum>0 ) {
#		$tracknum -= 1;
#	}

	$myrequest=Slim::Control::Request::executeRequest($client, ['stop']);
	$myrequest->getResults();

	$myrequest=Slim::Control::Request::executeRequest($client, ['playlistcontrol','cmd:load','album_id:'.$remoteMeta->{album_id}]);
#	$myrequest=Slim::Control::Request::executeRequest($client, ['playlistcontrol','cmd:load','album_id:'.$remoteMeta->{album_id},'play_index:'.$tracknum]);
	$myrequest->getResults();

	return;
}

sub initPlugin {
	my $class = shift;
	
	$buffer = Plugins::BookmarkHistory::Buffer->new();

	$prefs->init({
		buffer => {},
		bufferSize => 200,
		trackingPrecision => 5,
		threshhold  =>0,
		jumpback  =>0,
		sortDescending => 1,
		genreFilter => '',
	});
		
	$prefs->setChange( sub {
		$buffer->validate()
	}, 'bufferSize');
	
	$prefs->setChange( sub {
		$genreList = '';
	}, 'genreFilter');
	
	$prefs->migrate(1, sub {
		my $buffer = $prefs->get('buffer');
		
		$buffer = [ map {
			$_->{clients} = {};                
#			$_->{clients} = [] unless $_->{clients} && ref $_->{clients} eq 'ARRAY'; #installation error on fresh install: we need a hash, not an array as michaels "if this than that"
			$_;
		} %$buffer ];
		
		$prefs->set('buffer', $buffer);
		
	});

	if (main::WEBUI) {
		require Plugins::BookmarkHistory::Settings;
		Plugins::BookmarkHistory::Settings->new();
	}

	#Subscribe to playlist changes
	
	#Bookmarks menu works with loadalbum
	#Web interface seems to use addtracks
	#iPeng seems to use:
	#	playlist clear
	#	playlist stop
	#	playlist addtracks listRef ARRAY(0xXXXXXX) index%3A0
	#	playlist jump 0
	#	playlist open file ...

	#In all this cases use playlistCallback which looks through the playlist and if there is a bookmark for the album of the current playlists track then jump to this position

	#For up/down/move in the playlist the web interfaces and iPeng are using the "index" command.
	#Squeezeplay uses:
	#	playlist index N
	#	playlist stop
	#	playlist open 

	Slim::Control::Request::subscribe( \&playlistCallback, [['playlist'], ['loadtracks','loadalbum','addtracks' ]] );
#	Slim::Control::Request::subscribe( \&playlistCallback, [['playlist'], ['loadtracks','loadalbum','open','index']] );

	#Subscribe to newsong to jump to the correct position in the track once a bookmarked track is hit
	Slim::Control::Request::subscribe( \&newsongCallback, [['playlist'], ['newsong']] );

	# Subscribe to rescan to update album-id's of bookmarks after full scan
	Slim::Control::Request::subscribe( \&rescanCallback, [['rescan']]);

	# Subscribe to Rewind Button to set track positioning to 0
	Slim::Control::Request::subscribe( \&buttonJumpRewCallback, [['button']]);
	
	Slim::Menu::TrackInfo->registerInfoProvider( bookmarkHistory => (
		after => 'top',
		func  => \&nowPlayingInfoMenu,
	) );

	$class->SUPER::initPlugin(
		feed   => \&handleFeed,
		tag    => 'bookmarkHistory',
		is_app => 1,
	);
}

sub getDisplayName { 'PLUGIN_BOOKMARKHISTORY' }

sub handleFeed {
	my ($client, $cb, $params, $args) = @_;
	
	my $items = [];

	#$items = [];

	my $unsorted = $buffer->get();
	my @buffersortedbyts;
	
	#sort descending: http://stackoverflow.com/questions/10216419/sort-perl-hash-from-largest-to-smallest
	if (!$prefs->get('sortDescending')) {		
		@buffersortedbyts = sort { $unsorted->{$a}{ts} <=> $unsorted->{$b}{ts} } keys %$unsorted;
	} else {
		@buffersortedbyts = sort { $unsorted->{$b}{ts} <=> $unsorted->{$a}{ts} } keys %$unsorted;
	}
	
	#main::DEBUGLOG && $log->is_debug && $log->debug("buffersortedbyts: \n" . Data::Dump::dump(@buffersortedbyts));
	
	foreach my $id ( @buffersortedbyts ) {
		my $bufferitem=$unsorted->{$id};
		
		my $timestamp = Slim::Utils::DateTime::shortDateF($bufferitem->{ts});		
		#my $timestamp = Slim::Utils::DateTime::shortDateF($bufferitem->{ts}) . ' ' . Slim::Utils::DateTime::timeF($bufferitem->{ts});		
		my $url = $bufferitem->{url};
		
		my $item = {
			type  => 'link',
			name  => $timestamp . ' - ' .  $bufferitem->{album} . ' - ' . $bufferitem->{artist},
			line1 => $timestamp . ' - ' .  $bufferitem->{album},
			line2 => $bufferitem->{artist},
			style => 'itemplay',
			nextWindow => 'nowPlaying',
			url   => sub {
				my ($client, $cb, $params, $args) = @_;
				my $id = $args->{id};
				
				#playBookmark ( $client, $id);

				$cb->(
					playBookmark ( $client, $id)
				);
				
				#my ($client, $cb, $params, $args) = @_;
				#$cb->( Plugins::BookmarkHistory::Menu->menu( 
				#	$client, 
				#	$args->{id}, 
				#	{ menuMode => 'bookmarkHistory' } 
				#) );
			},
			passthrough => [{
				id => $id
			}]
		};
		
		#if ($bufferitem->{remote_title}) {
		#	$item->{name}  .= ' (' . $bufferitem->{remote_title} . ')';
		#	$item->{line2} .= ' - ' . $bufferitem->{remote_title};
		#}
		
		if ($bufferitem->{artwork_url}) {
			$item->{image} = $bufferitem->{artwork_url};
		}
		elsif ($bufferitem->{coverid}) {
			$item->{image} = 'music/' . $bufferitem->{coverid} . '/cover';
			$item->{icon}  = $bufferitem->{coverid};
		}
		
		$item->{name}  =~ s/^ - //;
		$item->{line1} =~ s/^ - //;
		$item->{line2} =~ s/^ - //;

		push @$items, $item;
	}
	
	$cb->({
		items => $items
	});
}

sub nowPlayingInfoMenu {
	my ( $client, $url, $track, $remoteMeta, $tags ) = @_;
$log->warn("INFOMENU  client:$client, url:$url, track:$track, meta:$remoteMeta, tags:$tags");
	return unless $client && $tags;

	# add item to now playing context menu
	if ( ($tags->{menuContext} && $tags->{menuContext} eq 'playlist' && $tags->{playlistIndex} == Slim::Player::Source::playingSongIndex($client))
		|| ($tags->{menuMode} && $tags->{menuMode} eq 'trackinfo' && !defined $tags->{playlistIndex})
	) {
		return {
			name => $client->string(getDisplayName()),
			type => 'link',
			url  => \&handleFeed,
			isContextMenu => 1,
		};
	}
	
	return;
}

sub getPlayedItem {
	my ($class, $id) = @_;
	return $buffer->getItem($id);
}

sub rescanCallback {

	$log->info("Verify bookmarks because of a rescan");

	$buffer->verifyBuffer();
}

sub playlistCallback {
	my $request = shift;
	my $client  = $request->client() || return;

	main::INFOLOG && $log->is_info && $log->info("playlistCallback client:".$client);

	my $cmd = $request->getRequestString();

	my $fromtrack = '-';
	my $numberoftracks = preferences('server')->get('maxPlaylistLength');
	

#	main::INFOLOG && $log->is_info && $log->info("getClientPlaylist client:$client fromtrack:$fromtrack numberoftracks:$numberoftracks");
	
#	$log->info($client.": playlists:\n" . Data::Dump::dump(Slim::Player::Playlist::playList($client)));
#	my $playList=Slim::Player::Playlist::playList($client);
#	$log->info($client.": playlist \n:" . Data::Dump::dump($playList));
#	
#	for my $i (0 .. $#{$playList}) {
#		my $trackinfo=$playList->[$i];
#		$log->info($client.": playlist $i:\n" . Data::Dump::dump($trackinfo));
#		$log->info($client.": playlist $i:\n" . $trackinfo->{title});
#		
#	$log->info("i:".$i." title:".$trackinfo->name());
#	#$log->info("i:".$i." title:".$trackinfo->albumid());
#	}

	#album_id genre url is tags:egu
	my $request = Slim::Control::Request::executeRequest($client, ['status', $fromtrack, $numberoftracks , 'tags:egu']);

#	my $timerequest = Slim::Control::Request::executeRequest($client, ['time','?']);

	my @items;

	if (!$request) {
		$log->warn("request failed. result is:" . Data::Dump::dump($request->getResults()));
		return;
	}
#		main::INFOLOG && $log->is_info && $log->info("request test. result is:" . Data::Dump::dump($request->getResults()));
	
	my $status;
	
	eval {
		$status = $request->getResults()->{playlist_loop};
	};
	
	if ($@) { #$@ is error code of eval
		$log->warn($client.": Failed to get song information: $@\n" . Data::Dump::dump($request->getResults()));
		return;
	}

	#first row: current song of playlist
	my $row = $status->[0];
	
	main::INFOLOG && $log->is_info && $log->info("current track of client:".$client." genre:".$row->{genre}." album_id:".$row->{album_id}." url:".$row->{url});
	
	if(!$row->{album_id}) {
		main::INFOLOG && $log->is_info && $log->info("no album_id. client:".$client);
		return;
	}
	
	#do we have a bookmark for the album of the current track?
	my $bufferitem = $buffer->getItem($row->{album_id});
	main::INFOLOG && $log->is_info && $log->info("bufferitem client:".$client." genre:".$bufferitem->{genre}." album_id:".$bufferitem->{album_id}." url:".$bufferitem->{url});

	if (!%$bufferitem) {
		main::INFOLOG && $log->is_info && $log->info("album of first track is not bookmarked. client:".$client);
		return;
	}

	if ($bufferitem->{url} eq "") {
		$log->warn("missing url in bookmark. client:".$client."album_id:".$bufferitem->{album_id});
		return;
	}


	if ($row->{url} eq "") {
		$log->warn("missing url in playlist. client:".$client."album_id:".$bufferitem->{album_id});
		return;
	}

	#did the client move in the playlist and did he move to a track different from the bookmarked track
	#if ( $cmd eq "playlist index" && $bufferitem->{url} ne $row->{url}) {
	#	main::INFOLOG && $log->is_info && $log->info("playlist index command");
	#	
	#	#update the bookmarked track
	#
	#	#we block small position values now in storePosition calls, so because the index command jumps to position 0 we have to update manually
	#	$bufferitem->{url}=$row->{url};
	#	$bufferitem->{position}=0;
	#
	#	return;
	#}

	#first row (=current playing track) is bookmarked track?
	
	if ($bufferitem->{url} eq $row->{url}) {
		main::INFOLOG && $log->is_info && $log->info("playlist current track is track of bookmark. client:".$client);
		return; 
	}

	#single row playlist
	if ( @$status == 1 ) {
		return;
	}
		
	main::INFOLOG && $log->is_info && $log->info("playlist rows url:".@$status);

	my $jumptracks=1;
	$row = $status->[$jumptracks];
	
	#loop through playlist while album is the same
	while($bufferitem->{album_id} eq $row->{album_id} & $jumptracks<@$status) {


		#track is the track of bookmark?
		if ($bufferitem->{url} eq $row->{url}) {
		
			#jumptracks contains the number of tracks we need to skip
			
			main::INFOLOG && $log->is_info && $log->info("executing index command index:+".$jumptracks." client:".$client);
			Slim::Control::Request::executeRequest($client, ['playlist','index','+'.$jumptracks]);
			return;

		}
		
		$jumptracks = $jumptracks +1;
		$row = $status->[$jumptracks];
		
	}
			
	main::INFOLOG && $log->is_info && $log->info("could not find bookmarked track in playlist. client:".$client);

}


sub newsongCallback {
	my $request = shift;
	my $client  = $request->client() || return;

	my $url = Slim::Player::Playlist::url($client);

	main::INFOLOG && $log->is_info && $log->info("newsongCallback client:".$client);
	
	#get Track info for current track of client
	my $url = Slim::Player::Playlist::url($client);
	my $item=getTrackItem($client,$url);

	my $bufferitem = $buffer->getItem($item->{album_id});

	if($bufferitem->{album_id}) {
		#main::INFOLOG && $log->is_info && $log->info("found current playing album_id in buffer:\n".Data::Dump::dump($bufferitem));
		main::INFOLOG && $log->is_info && $log->info($client.": buffer hit album_id:".$item->{album_id});
		#main::INFOLOG && $log->is_info && $log->info($client.": current tracknum:".$item->{tracknum}. " stored tracknum:".$bufferitem->{tracknum});

		my $jumpback=$prefs->get('jumpback');
		
		if( $item->{album_id}==$bufferitem->{album_id} && $item->{url} eq $bufferitem->{url} ) {
			main::INFOLOG && $log->is_info && $log->info($client.": found bufferitem. positions are item:".$item->{position}." bufferitem:".$bufferitem->{position});
			
#$log->info && $log->info("test bufferitem:".Data::Dump::dump($bufferitem));


			#we never need to scoll back. this callback is subscribed to the newsong event, so current playing position in track will always be close to 0
			if( 
					( ($item->{position})		>=0 																) #check if we have a value	 0
				&&	( ($item->{position})		<5									    							) #check if near the start (just to be safe	 )
				&&	( ($bufferitem->{position})	>$prefs->get('threshhold')  									    ) #check if we have a value	 
				&& 	( ($bufferitem->{position}) >( ($item->{position}) - ($prefs->get('trackingPrecision') || 5) ) 	) #check if buffer pos. larger than play pos.
			) {
				if ( $jumpback>0 && $bufferitem->{position}>$jumpback ) {
					$log->info($client.": execute time command to position:".$bufferitem->{position}." jumpback:".$jumpback);
					Slim::Control::Request::executeRequest($client, ['time',$bufferitem->{position}-$jumpback]);					
				} else {
					$log->info($client.": execute time command to position:".$bufferitem->{position});
					Slim::Control::Request::executeRequest($client, ['time',$bufferitem->{position}]);
				}
			}
		}
	}	

	if (!$activetracker) {
		#Slim::Utils::Scheduler::add_task(\&trackProgress);
		main::INFOLOG && $log->is_info && $log->info($client.": create timer for trackProgress");
		Slim::Utils::Timers::setTimer( "", Time::HiRes::time() + ($prefs->get('trackingPrecision') || 1), \&trackProgress );
		$activetracker=1;
	} else {
		main::DEBUGLOG && $log->is_debug && $log->debug($client.": activetracker:".$activetracker);	
	}

}

sub buttonJumpRewCallback {
	my $request = shift;
	my $client  = $request->client() || return;

	main::INFOLOG && $log->is_info && $log->info("buttonJumpRewCallback client:".$client);

	#my $cmd = $request->getRequestString();
    #main::INFOLOG && $log->info("buttonJumpRewCallback cmd: $cmd\n");
    #main::INFOLOG && $log->info("buttonJumpRewCallback results:".$request->getResults());
	#main::INFOLOG && $log->info("request:".Data::Dump::dump($request));
	#main::INFOLOG && $log->info("getParam:".$request->getParam('_buttoncode'));
	
	if ($request->getParam('_buttoncode') eq 'jump_rew') {
		main::INFOLOG && $log->info("buttonJumpRewCallback caught jump_rew");

		#get current track of client
		my $url = Slim::Player::Playlist::url($client);
		my $item=getTrackItem($client,$url);
		
		if($buffer->get()->{$item->{album_id}}) {
		
			#we block small position values now in storePosition calls
			#$item->{position}='0';
			#$buffer->storePosition($item);
			$buffer->get()->{$item->{album_id}}->{url}=$url;   #1.1.4: The Rewind button also jumps to the previous track, so we update the url also here, not only position
			$buffer->get()->{$item->{album_id}}->{position}=0;
		}
	}
	

}


###############################################################################
#Returns an item for a track url. item includes the position of the client in track
#Parameters are:
#client
#url: URL of the track

sub getTrackItem {

	my $client = shift;
	my $url = shift;

	#if ( !$client ) {
	#	main::INFOLOG && $log->is_info && $log->info("getTrackItem missing client:");
	#}
	
	my $request = Slim::Control::Request::executeRequest($client, ['songinfo', 0, 99, 'url:' . $url]);

	my $timerequest = Slim::Control::Request::executeRequest($client, ['time','?']);
    my $positionvalue = int($timerequest->getResult('_time'));

	my $item = {};
	
	if (!$request) {
		$log->warn("request failed. result is:" . Data::Dump::dump($request->getResults()));
#		main::INFOLOG && $log->is_info && $log->info("request failed. result is:" . Data::Dump::dump($request->getResults()));
		return undef;
	}
	
	my $songinfo;
	
	eval {
		$songinfo = $request->getResults()->{songinfo_loop};
	};
	
	if ($@) { #$@ is error code of eval
		$log->warn($client.": Failed to get song information: $@\n" . Data::Dump::dump($request->getResults()));
		return;
	}

	foreach (@$songinfo) {
		my ($k, $v) = each %$_;
		
		if ($k =~ /^(?:id|url|album_id|genre|album|artist|coverid)$/) {
			$item->{$k} = $v || '';
		}
	}

	if (!$item->{album_id}) {
		main::INFOLOG && $log->is_info && $log->info("no album id");
		return undef;
	}

	my $genreList ||= join('|', map {
		s/^\s*//;
		s/\s*$//;
		$_;
	} split(/,/, $prefs->get('genreFilter') || ''));

	# filter genres
	if ( $item->{genre} !~ /\b(?:$genreList)\b/i ) {
		main::INFOLOG && $log->is_info && $log->info("getTrackItem no genre match for genre:".$item->{genre});
		return undef;
	}

	$item->{url}    = $url;
	$item->{ts}     = time;
	$item->{position} = $positionvalue;

	main::INFOLOG && $log->is_info && $log->info("getTrackItem return client:".$client." album_id:".$item->{album_id}." positionvalue:".$positionvalue." url:".$item->{url});

	return $item;

}

sub itemAddLastTrackInfo {
	my ( $item) = @_;	
	
	if(!$item->{album_id}) {
		$log->warn("Missing id parameter");	
		return;
	}
	
	main::DEBUGLOG && $log->is_debug && $log->debug('check id:'.$item->{album_id});
	
	#Add info about last track in album to $info

	#get duration and url for all tracks in album
	my $request = Slim::Control::Request::executeRequest(undef,['titles', 0, 999, 'album_id:'.$item->{album_id}, 'sort:tracknum','tags:du']);

	if (!$request) {
		$log->warn("Failed to list album tracks for album_id:".$item->{album_id});
		return;
	}

	my $songinfo;
	
	eval {
		$songinfo = $request->getResults()->{titles_loop};
	};
	
	if ($@) {
		$log->warn("Failed to get list of titles for album_id ".$item->{album_id}.": $@\n" . Data::Dump::dump($request->getResults()));
		return;
	}

	#get last element of an array: http://www.perlhowto.com/array
	my $lasttrackinfo= @$songinfo[-1];


	my $lasttrackurl=%$lasttrackinfo->{url};
	my $lasttracklength=%$lasttrackinfo->{duration};
	
	$lasttracklength=int($lasttracklength);

	
	#main::DEBUGLOG && $log->is_debug && $log->debug("songinfo:\n" . Data::Dump::dump(@$songinfo[-1]));
	#main::DEBUGLOG && $log->is_debug && $log->debug("lasttrackinfo:\n" . Data::Dump::dump($lasttrackinfo));
	#main::DEBUGLOG && $log->is_debug && $log->debug("lasttrackurl:\n" . Data::Dump::dump($lasttrackurl));
	#main::DEBUGLOG && $log->is_debug && $log->debug("lasttracklength:\n" . Data::Dump::dump($lasttracklength));

	main::INFOLOG && $log->is_info && $log->info("Identified last track for album_id:".$item->{album_id}." url:".$lasttrackurl. " duration:".$lasttracklength);

	$item->{lasttrackurl}=$lasttrackurl;
	$item->{lasttracklength}=int($lasttracklength);

	return $item;

}

sub trackProgress {

	my $client;
	my $gotplayer=0;
		
	foreach $client (Slim::Player::Client::clients()) {

		if(Slim::Player::Source::playmode($client) eq 'play') {
			$gotplayer = 1;
			
			_logTrack($client);
		}
	}

	if ($gotplayer) {
		$activetracker=1;
		#main::DEBUGLOG && $log->is_debug && $log->debug("activetracker=".$activetracker);
		Slim::Utils::Timers::setTimer( "", Time::HiRes::time() + ($prefs->get('trackingPrecision') || 1), \&trackProgress );
	} else {
		main::INFOLOG && $log->is_info && $log->info("no client is playing. deactivate tracker");	
		$activetracker=0;
	}

	return $activetracker;
}

sub _logTrack {
	my $client = shift;

	my $url = Slim::Player::Playlist::url($client);

	my $meta=getTrackItem($client,$url);

	if (!$meta->{album_id}) {
		main::DEBUGLOG && $log->is_debug && $log->debug("no album id");
		return;
	}
	
	main::DEBUGLOG && $log->is_debug && $log->debug("id=". $meta->{album_id} . " position" . $meta->{position});

	$buffer->storePosition($meta);
}

1;

########################################################################################################################
package Plugins::BookmarkHistory::Buffer;

sub new {
	my $class = shift;
	
	my $self = {
		_buffer => $prefs->get('buffer') || {}
	};
	

	validate($self);
	updateFromDatabase($self);
	
	return bless $self, $class;
}

sub verifyBuffer {
	my $class = shift;

	main::INFOLOG && $log->is_info && $log->info("verifyBuffer has been called");
	
	validate($class);
	updateFromDatabase($class);
			
}

sub get {
	my $class = shift;
	return $class->{_buffer};
}

sub storePosition {
	my ($class, $item) = @_;

	my $id = $item->{album_id};
	my $buffer = $class->{_buffer};

#	main::DEBUGLOG && $log->is_debug && $log->debug("id " . $id);
	#main::DEBUGLOG && $log->is_debug && $log->debug("buffer: \n" . Data::Dump::dump($buffer));
	
	if(!$id) {
		$log->warn("Missing id parameter");	
		return;
	}
	
	if( $item->{position}<$prefs->get('threshhold') ) {
		main::DEBUGLOG && $log->is_debug && $log->debug("Ignoring because threshhold not reached");
		return;
	}
	
	if ( exists $buffer->{$id} ) {
		main::DEBUGLOG && $log->is_debug && $log->debug("Updating item: " . $id);
#		main::DEBUGLOG && $log->is_debug && $log->debug("Updating item: \n" . Data::Dump::dump($item));

		my $lasttrackurl=$buffer->{$id}->{lasttrackurl};
		my $lasttracklength=$buffer->{$id}->{lasttracklength};
		#my $threshhold=prefs->get('threshhold');

		main::DEBUGLOG && $log->is_debug && $log->debug("album check  album_id:".$item->{album_id}." position:".$item->{position}." lasttrackurl:".$lasttrackurl." lasttracklength:".$lasttracklength);

		if(
			$item->{url} eq $lasttrackurl and
			$item->{position}>=($lasttracklength-$prefs->get('threshhold'))
		) {
			main::INFOLOG && $log->is_info && $log->info("Approaching end of album. Delete Bookmark for album_id:".$id);
			delete $buffer->{$id};

		} else {
			#update buffer
			$buffer->{$id}->{position} = $item->{position};
			#$buffer->{$id}->{tracknum} = $item->{tracknum};
			#$buffer->{$id}->{title} = $item->{title};
			$buffer->{$id}->{ts} = $item->{ts};
			$buffer->{$id}->{url} = $item->{url};
			#update instead of setting hash to $item because otherwise lasttrackinfos would be lost
			#$buffer->{$id} = $item;

#			$log->info && $log->info("test buffer:".Data::Dump::dump($buffer->{$id}));

		}
		
	} else {
		main::DEBUGLOG && $log->is_debug && $log->debug("Switch to add mode");

		Plugins::BookmarkHistory::Plugin::itemAddLastTrackInfo($item);
		
		#Add info about last track in album to $info
	
		my $lasttrackurl=$item->{'lasttrackurl'};
		my $lasttracklength=$item->{'lasttracklength'};
		
		#check if we are near the end of the album
		if(
			$item->{url} eq $item->{'lasttrackurl'} &&
			$item->{position}>=( $item->{'lasttracklength'} - $prefs->get('threshhold') )
		) {
			main::INFOLOG && $log->is_info && $log->info("Ignoring new bookmark because near end of album_is:".$id);
		} else {
			main::INFOLOG && $log->is_info && $log->info("Adding item: " . $id);
			$buffer->{$id} = $item;

			#Validate buffer to check wether old bookmarks need to be dropped to keep buffer size to preference setting
			$class->validate();
		}

	}
}


sub getItem {
	my ($class, $id) = @_;
	
	return unless $id;
	
	#my ($item) = grep {
	#	$_->{_id} eq $id;
	#} %{$class->{_buffer}};
	
	#return $item;

	return $class->{_buffer}->{$id};
}

sub deleteItem {
	my ($class, $id) = @_;
	
	return unless $id;
	
	delete $class->{_buffer}->{$id};
}

sub getItemAt {
	my ($class, $index) = @_;
	
	$class->{_buffer}->[$index || 0];
}

#sub getPlayers {
#	my ($class) = @_;
#	
#	my $players;
#	
#	foreach my $item ( %{$class->{_buffer}} ) {
#		foreach my $player ( %{$item->{clients}} ) {
#			$players->{$player}++;
#		}
#	}
#	
#	return $players;
#}

sub updateFromDatabase {
	my $class = shift;
	# initialize buffer from prefs if we haven't yet
	$class->{_buffer} ||= $prefs->get('buffer');

	my $buffer 				= $class->{_buffer};
	my $newbuffer			={};

	my $exectime;
	main::INFOLOG && $log->is_info && $log->info("updateFromDatabase start") && ($exectime=time);
	
	my $oldbuffersize=scalar keys %$buffer;
	
	#check all buffer elements
	for my $id ( keys %$buffer ) {
#$log->info && $log->info("test before newitem:".$buffer->{$id}->{url});
		
		my $bufferitem=$buffer->{$id};

#		$log->info && $log->info("test beforeitem $id\n:".Data::Dump::dump($bufferitem));

		#get current data of track from database
		my $meta=Plugins::BookmarkHistory::Plugin::getTrackItem(undef,$bufferitem->{url});

		if (!$meta->{album_id}) {
			main::INFOLOG && $log->is_info && $log->info("drop bookmark because bookmarked track has no album id any more url:".$bufferitem->{url});
		
		} else  {
			my $newitem = {};
		
			#update from database
			$newitem->{album_id}	=$meta->{album_id};
			$newitem->{genre}		=$meta->{genre};
			$newitem->{album}		=$meta->{album};
			$newitem->{artist}		=$meta->{artist};
			$newitem->{coverid}		=$meta->{coverid};
			
			#keep from bookmark
			$newitem->{url}			=$bufferitem->{url};
			$newitem->{ts}			=$bufferitem->{ts};
#$log->info && $log->info("test newitem:".$newitem->{url});
			
			if( $bufferitem->{position} < $prefs->get('threshhold') ) {
				$newitem->{position}=0;
				$log->warn("clearing to small position. bufferitem:".$bufferitem->{url});
			} else {
				$newitem->{position} 	=$bufferitem->{position};
			}
			
			#add elements lastrackurl lasttracklength
			Plugins::BookmarkHistory::Plugin::itemAddLastTrackInfo($newitem);

#$log->info && $log->info("test newitem:".Data::Dump::dump($newitem));
						
			$newbuffer->{$meta->{album_id}}= $newitem;

		}


	}

	$class->{_buffer} = $newbuffer;
	$prefs->set('buffer', $class->{_buffer});

	my $newbuffersize=scalar keys %$buffer;
	
	main::INFOLOG && $log->is_info && $log->info("updateFromDatabase runtime:" . (time-$exectime). " old buffer size:".$oldbuffersize." new buffer size:".$newbuffersize);
	
}

sub validate {
	my $class = shift;
	
	# initialize buffer from prefs if we haven't yet
	$class->{_buffer} ||= $prefs->get('buffer');

	my $exectime;
	main::INFOLOG && $log->is_info && $log->info("validate start") && ($exectime=time);

	my $buffersize 			= $prefs->get('bufferSize') || 0;
	my $buffer 				= $class->{_buffer};
			
	if (ref($buffer) ne "HASH") {
		return;
	}

	my $currentbuffersize 	= scalar keys %$buffer; #http://stackoverflow.com/questions/1109095/how-can-i-find-the-number-of-keys-in-a-hash-in-perl

	#in case some entry of the buffer is not a hash (could only occur because of bugs)
	for my $id ( keys %$buffer ) {
		if (ref($buffer->{$id}) ne "HASH") {
			$log->error("Dropping invalid buffer entry. This is an error and should not happen. album_id:" . $buffer->{$id});
			delete $buffer->{$id};
		}
	}
	
	main::INFOLOG && $log->is_info && $log->info("Validate currentbuffersize:" . $currentbuffersize . " buffersize:" . $buffersize);
	
	if ( $currentbuffersize > $buffersize ) {

		$log->warning("Exeeded buffer size. Dropping items" );

		my $id;
		my $item;
		
		#recalculate number of buffer entries
		$currentbuffersize 	= scalar keys %$buffer;

		#http://perlmaven.com/how-to-sort-a-hash-of-hashes-by-value
		#
		#my @positioned = sort { $data->{$a}{Position} <=> $data->{$b}{Position} } keys %$data;
		#foreach my $k (@positioned) {
		#say $k;
		#}

		my @buffersortedbyts = sort { $buffer->{$a}{ts} <=> $buffer->{$b}{ts} } keys %$buffer;
		
		foreach $id ( 0..($currentbuffersize-$buffersize-1) ) {
			$log->warning("dropping bookmark album_id:" . $buffer->{$buffersortedbyts[$id]}->{id} . " album:" . $buffer->{$buffersortedbyts[$id]}->{album});
			delete $buffer->{$buffersortedbyts[$id]};
		}
		

	}

	$prefs->set('buffer', $class->{_buffer});
	
	main::INFOLOG && $log->is_info && $log->info("validate runtime:" . (time-$exectime));

}


1;
