package Plugins::DisableShuffle::Plugin;

use strict;
use base qw(Slim::Plugin::Base);
use Scalar::Util qw(blessed);

use Slim::Control::Request;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(string cstring);

my $prefs = preferences('plugin.disableshuffle');

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.disableshuffle',
	'defaultLevel' => 'INFO',
	'description'  => 'PLUGIN_DISABLESHUFFLE'	# Mitch originally used => getDisplayName(),
});

sub getDisplayName {
	return 'PLUGIN_DISABLESHUFFLE';
}

sub initPlugin {
	my $class = shift;
	
	main::DEBUGLOG && $log->is_debug && $log->debug("Initializing plugin DisableShuffle");
		
	$prefs->init({
		shuffle => 1,
		repeat  => 0,
		addplaylist =>0
	});

	if (main::WEBUI) {
		require Plugins::DisableShuffle::Settings;
		Plugins::DisableShuffle::Settings->new();
	}
 
	Slim::Control::Request::subscribe(\&changeShuffleCallback, [['playlist'], ['shuffle','repeat','addtracks','inserttracks']]);

	$class->SUPER::initPlugin();
}

sub changeShuffleCallback {
	my $request = shift;
	my $client  = $request->client() || return;
	my $cmd = $request->getRequestString();

	main::DEBUGLOG && $log->is_debug && $log->debug("changeShuffleCallback request:" . $cmd);

	if ($cmd =~ /playlist addtracks|inserttracks/) {

		if ($prefs->get('addplaylist')!=1) {
			main::DEBUGLOG && $log->is_debug && $log->debug("Ignoring add playlist callback");		
			return;
		}
		
		my $index = $request->getResult('index');
		main::DEBUGLOG && $log->is_debug && $log->debug("addtracks/inserttracks:" . $index);

		if( $index != 0 ) {
			main::DEBUGLOG && $log->is_debug && $log->debug("playlist index $index");
			Slim::Control::Request::executeRequest($client, ['playlist','index',"$index"]);
		}
		
	} elsif ($cmd =~ /playlist shuffle/) {

		if ($prefs->get('shuffle')!=1) {
			main::DEBUGLOG && $log->is_debug && $log->debug("Ignoring disable shuffle callback");		
			return;
		}
		
		if (preferences('server')->client($client)->get('shuffle')==0) {
			main::DEBUGLOG && $log->is_debug && $log->debug("callback: shuffle mode is already disabled");		
			return;
		}
		
		Slim::Control::Request::executeRequest($client, ['playlist','shuffle','0']);
		#my $request = Slim::Control::Request::executeRequest($client, ['playlist','shuffle','0']);
		main::DEBUGLOG && $log->is_debug && $log->debug("Sending disable shuffle request for client " . $client);

	} elsif ($cmd =~ /playlist repeat/) {

		if ($prefs->get('repeat')!=1) {
			main::DEBUGLOG && $log->is_debug && $log->debug("Ignoring disable repeat callback");		
			return;
		}
		
		if (preferences('server')->client($client)->get('repeat')==0) {
			main::DEBUGLOG && $log->is_debug && $log->debug("callback: repeat mode is already disabled");		
			return;
		}
		
		Slim::Control::Request::executeRequest($client, ['playlist','repeat','0']);
		main::DEBUGLOG && $log->is_debug && $log->debug("Sending disable repeat request for client " . $client);

	}

}


1;
