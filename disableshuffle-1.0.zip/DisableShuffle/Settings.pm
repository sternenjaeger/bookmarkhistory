package Plugins::DisableShuffle::Settings;

use strict;
use base qw(Slim::Web::Settings);
use Slim::Utils::Prefs;

my $prefs = preferences('plugin.disableshuffle');

sub name {
	return 'PLUGIN_DISABLESHUFFLE';
}

sub prefs {
	return ($prefs, 'shuffle', 'repeat', 'addplaylist');
}

sub page {
	return 'plugins/DisableShuffle/settings.html';
}

1;